
  # Telemedicine Healthcare Solution

  This is a code bundle for Telemedicine Healthcare Solution. The original project is available at https://www.figma.com/design/ouaz3TGNcx8ZjFgjQlhvws/Telemedicine-Healthcare-Solution.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  