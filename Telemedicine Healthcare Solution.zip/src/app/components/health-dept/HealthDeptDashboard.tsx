import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Stethoscope, TrendingUp, Users, MapPin, AlertTriangle, FileText, LogOut } from 'lucide-react';
import { RegionalOverview } from './RegionalOverview';
import { PolicyManagement } from './PolicyManagement';
import { ResourceAllocation } from './ResourceAllocation';

interface HealthDeptDashboardProps {
  user: any;
  onLogout: () => void;
}

export function HealthDeptDashboard({ user, onLogout }: HealthDeptDashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <RegionalOverview user={user} />;
      case 'policy':
        return <PolicyManagement user={user} />;
      case 'resources':
        return <ResourceAllocation user={user} />;
      default:
        return (
          <div className="space-y-6">
            {/* Welcome Section */}
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800">ਸਤਿ ਸ਼੍ਰੀ ਅਕਾਲ, {user.name}!</CardTitle>
                <p className="text-green-600">Punjab Health Department - Administrative Dashboard</p>
              </CardHeader>
            </Card>

            {/* State-wide Health Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Users className="w-8 h-8 mx-auto text-green-600 mb-2" />
                  <h3 className="text-2xl font-bold">2.8M</h3>
                  <p className="text-sm text-gray-600">Population Served</p>
                  <p className="text-xs text-green-600">Rural Punjab</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Stethoscope className="w-8 h-8 mx-auto text-green-600 mb-2" />
                  <h3 className="text-2xl font-bold">487</h3>
                  <p className="text-sm text-gray-600">Healthcare Facilities</p>
                  <p className="text-xs text-yellow-600">52% under-staffed</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <MapPin className="w-8 h-8 mx-auto text-green-600 mb-2" />
                  <h3 className="text-2xl font-bold">12,456</h3>
                  <p className="text-sm text-gray-600">Villages Covered</p>
                  <p className="text-xs text-green-600">98% connectivity</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <TrendingUp className="w-8 h-8 mx-auto text-green-600 mb-2" />
                  <h3 className="text-2xl font-bold">₹47.2Cr</h3>
                  <p className="text-sm text-gray-600">Budget Allocated</p>
                  <p className="text-xs text-blue-600">FY 2024-25</p>
                </CardContent>
              </Card>
            </div>

            {/* Critical Alerts */}
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center">
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Critical Health Alerts - Statewide
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-red-100 rounded-lg">
                    <div>
                      <p className="font-medium text-red-800">Doctor Shortage Crisis - Nabha District</p>
                      <p className="text-sm text-red-600">Only 11 out of 23 sanctioned doctors available at Civil Hospital</p>
                    </div>
                    <Badge className="bg-red-600">URGENT</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-yellow-100 rounded-lg">
                    <div>
                      <p className="font-medium text-yellow-800">Medicine Stock Alert - Rural Areas</p>
                      <p className="text-sm text-yellow-600">Critical shortage of essential medicines in 67 PHCs</p>
                    </div>
                    <Badge className="bg-yellow-600">HIGH</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-orange-100 rounded-lg">
                    <div>
                      <p className="font-medium text-orange-800">Infrastructure Maintenance</p>
                      <p className="text-sm text-orange-600">23 healthcare facilities need immediate repair</p>
                    </div>
                    <Badge className="bg-orange-600">MEDIUM</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* District Performance Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-green-800">District Performance Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Nabha District */}
                    <div className="p-4 border border-red-200 rounded-lg bg-red-50">
                      <h3 className="font-medium text-red-800">Nabha District</h3>
                      <div className="mt-2 space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Doctor Availability:</span>
                          <span className="text-red-600 font-medium">48%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Villages Served:</span>
                          <span>173</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Telemedicine Usage:</span>
                          <span className="text-green-600">+31%</span>
                        </div>
                      </div>
                    </div>

                    {/* Patiala District */}
                    <div className="p-4 border border-green-200 rounded-lg bg-green-50">
                      <h3 className="font-medium text-green-800">Patiala District</h3>
                      <div className="mt-2 space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Doctor Availability:</span>
                          <span className="text-green-600 font-medium">87%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Villages Served:</span>
                          <span>298</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Telemedicine Usage:</span>
                          <span className="text-green-600">+24%</span>
                        </div>
                      </div>
                    </div>

                    {/* Ludhiana District */}
                    <div className="p-4 border border-yellow-200 rounded-lg bg-yellow-50">
                      <h3 className="font-medium text-yellow-800">Ludhiana District</h3>
                      <div className="mt-2 space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Doctor Availability:</span>
                          <span className="text-yellow-600 font-medium">72%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Villages Served:</span>
                          <span>412</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Telemedicine Usage:</span>
                          <span className="text-green-600">+18%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('overview')}>
                <CardHeader className="text-center">
                  <TrendingUp className="w-8 h-8 mx-auto text-green-600" />
                  <CardTitle className="text-lg">Regional Overview</CardTitle>
                  <p className="text-sm text-gray-600">Statewide health analytics</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('policy')}>
                <CardHeader className="text-center">
                  <FileText className="w-8 h-8 mx-auto text-green-600" />
                  <CardTitle className="text-lg">Policy Management</CardTitle>
                  <p className="text-sm text-gray-600">Health policies & guidelines</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('resources')}>
                <CardHeader className="text-center">
                  <Users className="w-8 h-8 mx-auto text-green-600" />
                  <CardTitle className="text-lg">Resource Allocation</CardTitle>
                  <p className="text-sm text-gray-600">Budget & staff management</p>
                </CardHeader>
              </Card>
            </div>

            {/* Recent Government Initiatives */}
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">Recent Punjab Health Initiatives</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between items-center">
                    <span>Sarbat Sehat Bima Yojana - Universal Health Coverage</span>
                    <Badge variant="secondary">Active</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Telemedicine Infrastructure Development</span>
                    <Badge className="bg-green-600">Expanding</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Rural Doctor Recruitment Drive</span>
                    <Badge className="bg-orange-600">In Progress</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Primary Health Center Upgradation</span>
                    <Badge className="bg-blue-600">Phase 2</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Budget Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-green-800">FY 2024-25 Health Budget Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <h3 className="text-xl font-bold text-green-700">₹47.2 Cr</h3>
                    <p className="text-sm text-gray-600">Total Allocated</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-blue-700">₹28.1 Cr</h3>
                    <p className="text-sm text-gray-600">Utilized (59.5%)</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-700">₹12.4 Cr</h3>
                    <p className="text-sm text-gray-600">Infrastructure</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-purple-700">₹6.7 Cr</h3>
                    <p className="text-sm text-gray-600">Emergency Fund</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-green-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-green-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-xl text-green-800">Punjab Health Department Portal</h1>
              <div className="hidden md:flex space-x-4">
                <Button 
                  variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('dashboard')}
                  className={activeTab === 'dashboard' ? 'bg-green-600 hover:bg-green-700' : ''}
                >
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === 'overview' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('overview')}
                  className={activeTab === 'overview' ? 'bg-green-600 hover:bg-green-700' : ''}
                >
                  Regional Overview
                </Button>
                <Button 
                  variant={activeTab === 'policy' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('policy')}
                  className={activeTab === 'policy' ? 'bg-green-600 hover:bg-green-700' : ''}
                >
                  Policy Management
                </Button>
                <Button 
                  variant={activeTab === 'resources' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('resources')}
                  className={activeTab === 'resources' ? 'bg-green-600 hover:bg-green-700' : ''}
                >
                  Resource Allocation
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">{user.name} - Health Dept</span>
              <Button variant="outline" onClick={onLogout} className="border-green-300 text-green-700 hover:bg-green-50">
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}