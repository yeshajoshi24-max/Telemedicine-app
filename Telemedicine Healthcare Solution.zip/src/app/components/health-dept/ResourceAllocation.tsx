import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { DollarSign, Users, Building2, TrendingUp, AlertCircle } from 'lucide-react';

interface ResourceAllocationProps {
  user: any;
}

export function ResourceAllocation({ user }: ResourceAllocationProps) {
  const [selectedDistrict, setSelectedDistrict] = useState('all');
  const [selectedYear, setSelectedYear] = useState('2024');

  // Budget allocation data
  const budgetData = [
    { category: 'Staff Salaries', allocated: 18.5, utilized: 16.2, percentage: 39 },
    { category: 'Infrastructure', allocated: 12.4, utilized: 8.9, percentage: 26 },
    { category: 'Medicine & Supplies', allocated: 8.7, utilized: 7.8, percentage: 18 },
    { category: 'Technology', allocated: 4.2, utilized: 3.1, percentage: 9 },
    { category: 'Training & Development', allocated: 2.1, utilized: 1.8, percentage: 4 },
    { category: 'Emergency Fund', allocated: 1.3, utilized: 0.4, percentage: 3 }
  ];

  const staffingData = [
    { district: 'Nabha', sanctioned: 23, current: 11, shortage: 12 },
    { district: 'Patiala', sanctioned: 45, current: 39, shortage: 6 },
    { district: 'Ludhiana', sanctioned: 67, current: 48, shortage: 19 },
    { district: 'Amritsar', sanctioned: 52, current: 47, shortage: 5 },
    { district: 'Jalandhar', sanctioned: 38, current: 26, shortage: 12 },
    { district: 'Bathinda', sanctioned: 31, current: 17, shortage: 14 }
  ];

  const priorityProjects = [
    {
      id: 1,
      name: 'Nabha Hospital Doctor Recruitment',
      budget: 2.8,
      timeline: '3 months',
      status: 'urgent',
      impact: 'High - Serves 173 villages'
    },
    {
      id: 2,
      name: 'Rural Telemedicine Infrastructure',
      budget: 4.1,
      timeline: '6 months',
      status: 'in-progress',
      impact: 'Medium - 50 PHCs'
    },
    {
      id: 3,
      name: 'ASHA Worker Training Program',
      budget: 1.6,
      timeline: '4 months',
      status: 'planned',
      impact: 'High - 1200 workers'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'planned': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const pieChartData = budgetData.map(item => ({
    name: item.category,
    value: item.allocated,
    color: ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'][budgetData.indexOf(item)]
  }));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <DollarSign className="w-5 h-5 mr-2" />
            Resource Allocation & Budget Management
          </CardTitle>
          <p className="text-sm text-gray-600">
            Manage budget allocation, staffing, and resource distribution across Punjab health system
          </p>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">District</label>
              <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Districts</SelectItem>
                  <SelectItem value="nabha">Nabha</SelectItem>
                  <SelectItem value="patiala">Patiala</SelectItem>
                  <SelectItem value="ludhiana">Ludhiana</SelectItem>
                  <SelectItem value="amritsar">Amritsar</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Financial Year</label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024">FY 2024-25</SelectItem>
                  <SelectItem value="2023">FY 2023-24</SelectItem>
                  <SelectItem value="2022">FY 2022-23</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium mb-2">Budget Summary</label>
              <div className="flex items-center space-x-4 text-sm">
                <div>
                  <span className="text-gray-600">Allocated: </span>
                  <span className="font-bold text-green-600">₹47.2 Cr</span>
                </div>
                <div>
                  <span className="text-gray-600">Utilized: </span>
                  <span className="font-bold text-blue-600">₹38.2 Cr (81%)</span>
                </div>
                <div>
                  <span className="text-gray-600">Remaining: </span>
                  <span className="font-bold text-orange-600">₹9.0 Cr</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Budget Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <DollarSign className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">₹47.2Cr</h3>
            <p className="text-sm text-gray-600">Total Budget</p>
            <p className="text-xs text-green-600">FY 2024-25</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Users className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">1,248</h3>
            <p className="text-sm text-gray-600">Staff Count</p>
            <p className="text-xs text-red-600">Need 856 more</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Building2 className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">487</h3>
            <p className="text-sm text-gray-600">Facilities</p>
            <p className="text-xs text-yellow-600">52% under-staffed</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <TrendingUp className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">81%</h3>
            <p className="text-sm text-gray-600">Budget Utilization</p>
            <p className="text-xs text-green-600">Above target</p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Budget Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Budget Distribution (₹Cr)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieChartData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`₹${value} Cr`, 'Budget']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Staffing Analysis */}
        <Card>
          <CardHeader>
            <CardTitle>District-wise Staff Shortage</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={staffingData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="district" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="current" fill="#22c55e" name="Current Staff" />
                <Bar dataKey="shortage" fill="#ef4444" name="Shortage" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Budget Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Budget Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3">Category</th>
                  <th className="text-right p-3">Allocated (₹Cr)</th>
                  <th className="text-right p-3">Utilized (₹Cr)</th>
                  <th className="text-right p-3">Utilization %</th>
                  <th className="text-right p-3">Remaining (₹Cr)</th>
                  <th className="text-center p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {budgetData.map((item, index) => {
                  const utilizationPercent = ((item.utilized / item.allocated) * 100).toFixed(1);
                  const remaining = (item.allocated - item.utilized).toFixed(1);
                  
                  return (
                    <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="p-3 font-medium">{item.category}</td>
                      <td className="p-3 text-right">₹{item.allocated}</td>
                      <td className="p-3 text-right">₹{item.utilized}</td>
                      <td className="p-3 text-right">{utilizationPercent}%</td>
                      <td className="p-3 text-right">₹{remaining}</td>
                      <td className="p-3 text-center">
                        {parseFloat(utilizationPercent) > 85 && (
                          <Badge className="bg-green-100 text-green-800">On Track</Badge>
                        )}
                        {parseFloat(utilizationPercent) >= 60 && parseFloat(utilizationPercent) <= 85 && (
                          <Badge className="bg-yellow-100 text-yellow-800">Monitor</Badge>
                        )}
                        {parseFloat(utilizationPercent) < 60 && (
                          <Badge className="bg-red-100 text-red-800">Underutilized</Badge>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Priority Projects */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <AlertCircle className="w-5 h-5 mr-2" />
            Priority Resource Allocation Projects
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {priorityProjects.map((project) => (
              <div key={project.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-medium">{project.name}</h3>
                      <Badge className={getStatusColor(project.status)}>
                        {project.status.replace('-', ' ')}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Budget: </span>
                        <span>₹{project.budget} Cr</span>
                      </div>
                      <div>
                        <span className="font-medium">Timeline: </span>
                        <span>{project.timeline}</span>
                      </div>
                      <div>
                        <span className="font-medium">Impact: </span>
                        <span>{project.impact}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="ml-4">
                    <Button size="sm" className="bg-green-600 hover:bg-green-700">
                      Approve Budget
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Budget Reallocation Recommendations */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardHeader>
          <CardTitle className="text-yellow-800">Budget Reallocation Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <p className="font-medium text-yellow-800">Infrastructure → Emergency Staffing</p>
              <p className="text-yellow-700">Reallocate ₹3.5 Cr from underutilized infrastructure budget to immediate doctor recruitment</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <p className="font-medium text-blue-800">Technology → Training Programs</p>
              <p className="text-blue-700">Redirect ₹1.1 Cr to accelerate ASHA worker digital training initiatives</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <p className="font-medium text-green-800">Emergency Fund → Telemedicine</p>
              <p className="text-green-700">Utilize ₹0.9 Cr from emergency reserve for rural connectivity improvement</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button variant="outline" className="p-4 h-auto flex flex-col items-center border-green-300">
          <DollarSign className="w-6 h-6 mb-2 text-green-600" />
          <span>Approve Budget Request</span>
        </Button>
        <Button variant="outline" className="p-4 h-auto flex flex-col items-center border-green-300">
          <Users className="w-6 h-6 mb-2 text-green-600" />
          <span>Staff Deployment Plan</span>
        </Button>
        <Button variant="outline" className="p-4 h-auto flex flex-col items-center border-green-300">
          <TrendingUp className="w-6 h-6 mb-2 text-green-600" />
          <span>Generate Budget Report</span>
        </Button>
      </div>
    </div>
  );
}