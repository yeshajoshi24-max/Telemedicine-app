import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { FileText, Plus, Eye, Download, Calendar } from 'lucide-react';

interface PolicyManagementProps {
  user: any;
}

export function PolicyManagement({ user }: PolicyManagementProps) {
  const [activeView, setActiveView] = useState('policies');

  const policies = [
    {
      id: 1,
      title: 'Rural Telemedicine Implementation Guidelines',
      category: 'Digital Health',
      status: 'active',
      version: '2.1',
      lastUpdated: '2024-11-15',
      effectiveDate: '2024-12-01',
      description: 'Comprehensive guidelines for implementing telemedicine services in rural Punjab'
    },
    {
      id: 2,
      title: 'ASHA Worker Incentive Structure',
      category: 'Human Resources',
      status: 'active',
      version: '1.3',
      lastUpdated: '2024-10-20',
      effectiveDate: '2024-11-01',
      description: 'Updated compensation and incentive framework for community health workers'
    },
    {
      id: 3,
      title: 'Emergency Medical Response Protocol',
      category: 'Emergency Care',
      status: 'draft',
      version: '3.0',
      lastUpdated: '2024-12-10',
      effectiveDate: '2025-01-15',
      description: 'Standardized emergency response procedures for rural healthcare facilities'
    },
    {
      id: 4,
      title: 'Medicine Procurement & Distribution Policy',
      category: 'Supply Chain',
      status: 'under_review',
      version: '1.8',
      lastUpdated: '2024-12-05',
      effectiveDate: '2025-02-01',
      description: 'Guidelines for efficient medicine procurement and distribution to rural areas'
    }
  ];

  const guidelines = [
    {
      id: 1,
      title: 'COVID-19 Prevention in Rural Areas',
      type: 'Health Guidelines',
      audience: 'Healthcare Workers',
      lastUpdated: '2024-11-30'
    },
    {
      id: 2,
      title: 'Maternal Health Best Practices',
      type: 'Clinical Guidelines',
      audience: 'Doctors & ASHA Workers',
      lastUpdated: '2024-10-15'
    },
    {
      id: 3,
      title: 'Digital Health Record Management',
      type: 'Technical Guidelines',
      audience: 'IT & Medical Staff',
      lastUpdated: '2024-12-01'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'under_review': return 'bg-blue-100 text-blue-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Digital Health': return 'bg-blue-100 text-blue-800';
      case 'Human Resources': return 'bg-purple-100 text-purple-800';
      case 'Emergency Care': return 'bg-red-100 text-red-800';
      case 'Supply Chain': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-green-800">
                <FileText className="w-5 h-5 mr-2" />
                Health Policy & Guidelines Management
              </CardTitle>
              <p className="text-sm text-gray-600">
                Manage state health policies, guidelines, and regulatory frameworks
              </p>
            </div>
            <div className="flex space-x-2">
              <Button 
                variant={activeView === 'policies' ? 'default' : 'outline'}
                onClick={() => setActiveView('policies')}
                className={activeView === 'policies' ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                Policies
              </Button>
              <Button 
                variant={activeView === 'guidelines' ? 'default' : 'outline'}
                onClick={() => setActiveView('guidelines')}
                className={activeView === 'guidelines' ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                Guidelines
              </Button>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-1" />
                New Policy
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {activeView === 'policies' ? (
        <>
          {/* Policy Status Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6 text-center">
                <h3 className="text-2xl font-bold text-green-600">
                  {policies.filter(p => p.status === 'active').length}
                </h3>
                <p className="text-sm text-gray-600">Active Policies</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <h3 className="text-2xl font-bold text-yellow-600">
                  {policies.filter(p => p.status === 'draft').length}
                </h3>
                <p className="text-sm text-gray-600">Draft Policies</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <h3 className="text-2xl font-bold text-blue-600">
                  {policies.filter(p => p.status === 'under_review').length}
                </h3>
                <p className="text-sm text-gray-600">Under Review</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <h3 className="text-2xl font-bold text-purple-600">47</h3>
                <p className="text-sm text-gray-600">Total Policies</p>
              </CardContent>
            </Card>
          </div>

          {/* Policies List */}
          <div className="space-y-4">
            {policies.map((policy) => (
              <Card key={policy.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-medium">{policy.title}</h3>
                        <Badge className={getStatusColor(policy.status)}>
                          {policy.status.replace('_', ' ')}
                        </Badge>
                        <Badge className={getCategoryColor(policy.category)}>
                          {policy.category}
                        </Badge>
                      </div>

                      <p className="text-gray-600 mb-3">{policy.description}</p>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Version:</span>
                          <span className="ml-1">{policy.version}</span>
                        </div>
                        <div>
                          <span className="font-medium">Last Updated:</span>
                          <span className="ml-1">{new Date(policy.lastUpdated).toLocaleDateString()}</span>
                        </div>
                        <div>
                          <span className="font-medium">Effective Date:</span>
                          <span className="ml-1">{new Date(policy.effectiveDate).toLocaleDateString()}</span>
                        </div>
                        <div>
                          <span className="font-medium">Policy ID:</span>
                          <span className="ml-1">PH-{policy.id.toString().padStart(3, '0')}</span>
                        </div>
                      </div>
                    </div>

                    <div className="ml-4 space-y-2">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Recent Policy Updates */}
          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-800">Recent Policy Updates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center">
                  <span>Rural Telemedicine Implementation Guidelines v2.1 published</span>
                  <span className="text-gray-500">Nov 15, 2024</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Emergency Medical Response Protocol v3.0 submitted for review</span>
                  <span className="text-gray-500">Dec 10, 2024</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Medicine Procurement Policy v1.8 under stakeholder review</span>
                  <span className="text-gray-500">Dec 5, 2024</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          {/* Guidelines List */}
          <div className="space-y-4">
            {guidelines.map((guideline) => (
              <Card key={guideline.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-medium">{guideline.title}</h3>
                        <Badge variant="secondary">{guideline.type}</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Target Audience:</span>
                          <span className="ml-1">{guideline.audience}</span>
                        </div>
                        <div>
                          <span className="font-medium">Last Updated:</span>
                          <span className="ml-1">{new Date(guideline.lastUpdated).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="ml-4 space-y-2">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Upcoming Guidelines */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">Upcoming Guidelines & Training</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-blue-100 rounded-lg">
                  <div>
                    <p className="font-medium text-blue-800">Mental Health Support in Rural Areas</p>
                    <p className="text-sm text-blue-600">Comprehensive guide for addressing mental health challenges</p>
                  </div>
                  <Badge className="bg-blue-600">Jan 2025</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-purple-100 rounded-lg">
                  <div>
                    <p className="font-medium text-purple-800">AI-Assisted Diagnosis Guidelines</p>
                    <p className="text-sm text-purple-600">Framework for integrating AI tools in rural healthcare</p>
                  </div>
                  <Badge className="bg-purple-600">Feb 2025</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Policy Development Pipeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-green-800">Policy Development Pipeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-center">
            <div className="p-4 bg-yellow-50 rounded-lg">
              <h4 className="font-medium text-yellow-800">Research</h4>
              <p className="text-2xl font-bold text-yellow-600">3</p>
              <p className="text-sm text-gray-600">policies</p>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-800">Drafting</h4>
              <p className="text-2xl font-bold text-blue-600">2</p>
              <p className="text-sm text-gray-600">policies</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <h4 className="font-medium text-purple-800">Review</h4>
              <p className="text-2xl font-bold text-purple-600">1</p>
              <p className="text-sm text-gray-600">policy</p>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg">
              <h4 className="font-medium text-orange-800">Approval</h4>
              <p className="text-2xl font-bold text-orange-600">1</p>
              <p className="text-sm text-gray-600">policy</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-medium text-green-800">Implementation</h4>
              <p className="text-2xl font-bold text-green-600">2</p>
              <p className="text-sm text-gray-600">policies</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-green-800">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="p-4 h-auto flex flex-col items-center">
              <FileText className="w-6 h-6 mb-2" />
              <span>Create Policy Template</span>
            </Button>
            <Button variant="outline" className="p-4 h-auto flex flex-col items-center">
              <Calendar className="w-6 h-6 mb-2" />
              <span>Schedule Review Meeting</span>
            </Button>
            <Button variant="outline" className="p-4 h-auto flex flex-col items-center">
              <Download className="w-6 h-6 mb-2" />
              <span>Policy Archive Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}