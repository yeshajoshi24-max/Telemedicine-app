import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { MapPin, TrendingUp, Users, Building2 } from 'lucide-react';

interface RegionalOverviewProps {
  user: any;
}

export function RegionalOverview({ user }: RegionalOverviewProps) {
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedMetric, setSelectedMetric] = useState('doctor_availability');

  // Sample data for regional health metrics
  const regionalData = [
    { district: 'Nabha', doctorAvailability: 48, telemedicine: 135, budget: 4.2, population: 187000 },
    { district: 'Patiala', doctorAvailability: 87, telemedicine: 298, budget: 8.7, population: 389000 },
    { district: 'Ludhiana', doctorAvailability: 72, telemedicine: 412, budget: 12.3, population: 587000 },
    { district: 'Amritsar', doctorAvailability: 91, telemedicine: 356, budget: 9.8, population: 425000 },
    { district: 'Jalandhar', doctorAvailability: 68, telemedicine: 289, budget: 7.1, population: 342000 },
    { district: 'Bathinda', doctorAvailability: 55, telemedicine: 178, budget: 5.4, population: 256000 }
  ];

  const timeSeriesData = [
    { month: 'Jul', consultations: 2450, referrals: 189, outcomes: 94 },
    { month: 'Aug', consultations: 2890, referrals: 201, outcomes: 96 },
    { month: 'Sep', consultations: 3120, referrals: 178, outcomes: 95 },
    { month: 'Oct', consultations: 2980, referrals: 156, outcomes: 97 },
    { month: 'Nov', consultations: 3350, referrals: 143, outcomes: 98 },
    { month: 'Dec', consultations: 3780, referrals: 134, outcomes: 96 }
  ];

  const getPerformanceColor = (value: number, metric: string) => {
    if (metric === 'doctor_availability') {
      if (value >= 80) return 'text-green-600';
      if (value >= 60) return 'text-yellow-600';
      return 'text-red-600';
    }
    return 'text-blue-600';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <MapPin className="w-5 h-5 mr-2" />
            Punjab State Health Overview
          </CardTitle>
          <p className="text-sm text-gray-600">
            Comprehensive health metrics across all districts and rural areas
          </p>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Region/District</label>
              <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Districts</SelectItem>
                  <SelectItem value="nabha">Nabha</SelectItem>
                  <SelectItem value="patiala">Patiala</SelectItem>
                  <SelectItem value="ludhiana">Ludhiana</SelectItem>
                  <SelectItem value="amritsar">Amritsar</SelectItem>
                  <SelectItem value="jalandhar">Jalandhar</SelectItem>
                  <SelectItem value="bathinda">Bathinda</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Primary Metric</label>
              <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="doctor_availability">Doctor Availability</SelectItem>
                  <SelectItem value="telemedicine">Telemedicine Usage</SelectItem>
                  <SelectItem value="budget">Budget Utilization</SelectItem>
                  <SelectItem value="population">Population Coverage</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total Rural Population</p>
                <p className="text-2xl font-bold text-green-600">2.8M</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <Building2 className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">487</h3>
            <p className="text-sm text-gray-600">Healthcare Facilities</p>
            <p className="text-xs text-yellow-600">52% under-staffed</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Users className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">1,248</h3>
            <p className="text-sm text-gray-600">Active Doctors</p>
            <p className="text-xs text-red-600">Need 856 more</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <TrendingUp className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">18,467</h3>
            <p className="text-sm text-gray-600">Monthly Consultations</p>
            <p className="text-xs text-green-600">+23% growth</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <MapPin className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">98.2%</h3>
            <p className="text-sm text-gray-600">Village Coverage</p>
            <p className="text-xs text-green-600">12,456 villages</p>
          </CardContent>
        </Card>
      </div>

      {/* District Performance Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>District Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={regionalData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="district" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="doctorAvailability" fill="#22c55e" name="Doctor Availability %" />
              <Bar dataKey="telemedicine" fill="#3b82f6" name="Telemedicine Users" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Telemedicine Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Telemedicine Adoption Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={timeSeriesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="consultations" stroke="#22c55e" name="Total Consultations" strokeWidth={2} />
              <Line type="monotone" dataKey="referrals" stroke="#ef4444" name="Hospital Referrals" strokeWidth={2} />
              <Line type="monotone" dataKey="outcomes" stroke="#8b5cf6" name="Success Rate %" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* District Details Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed District Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3">District</th>
                  <th className="text-center p-3">Population</th>
                  <th className="text-center p-3">Doctor Availability</th>
                  <th className="text-center p-3">Telemedicine Users</th>
                  <th className="text-center p-3">Budget (₹Cr)</th>
                  <th className="text-center p-3">Performance</th>
                </tr>
              </thead>
              <tbody>
                {regionalData.map((district, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="p-3 font-medium">{district.district}</td>
                    <td className="p-3 text-center">{(district.population / 1000).toFixed(0)}K</td>
                    <td className={`p-3 text-center font-medium ${getPerformanceColor(district.doctorAvailability, 'doctor_availability')}`}>
                      {district.doctorAvailability}%
                    </td>
                    <td className="p-3 text-center">{district.telemedicine}</td>
                    <td className="p-3 text-center">₹{district.budget}</td>
                    <td className="p-3 text-center">
                      {district.doctorAvailability >= 80 && (
                        <Badge className="bg-green-100 text-green-800">Excellent</Badge>
                      )}
                      {district.doctorAvailability >= 60 && district.doctorAvailability < 80 && (
                        <Badge className="bg-yellow-100 text-yellow-800">Good</Badge>
                      )}
                      {district.doctorAvailability < 60 && (
                        <Badge className="bg-red-100 text-red-800">Needs Improvement</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Priority Actions */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardHeader>
          <CardTitle className="text-yellow-800">Priority Action Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-red-100 rounded-lg">
              <div>
                <p className="font-medium text-red-800">Immediate Doctor Recruitment - Nabha District</p>
                <p className="text-sm text-red-600">Deploy mobile medical units and expedite hiring process</p>
              </div>
              <Badge className="bg-red-600">Critical</Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-orange-100 rounded-lg">
              <div>
                <p className="font-medium text-orange-800">Telemedicine Infrastructure - Rural Areas</p>
                <p className="text-sm text-orange-600">Expand high-speed internet connectivity to remaining 2% villages</p>
              </div>
              <Badge className="bg-orange-600">High</Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-blue-100 rounded-lg">
              <div>
                <p className="font-medium text-blue-800">Budget Reallocation</p>
                <p className="text-sm text-blue-600">Redirect unused infrastructure funds to emergency staffing</p>
              </div>
              <Badge className="bg-blue-600">Medium</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Success Stories */}
      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Success Stories & Best Practices</CardTitle>
        </CardHeader>
        <CardContent className="text-green-700">
          <ul className="space-y-2">
            <li>• <strong>Patiala District:</strong> Achieved 87% doctor availability through innovative retention incentives</li>
            <li>• <strong>Amritsar:</strong> Reduced patient travel time by 65% through strategic telemedicine deployment</li>
            <li>• <strong>Ludhiana:</strong> Implemented successful ASHA worker training program, improving rural health outcomes by 34%</li>
            <li>• <strong>State-wide:</strong> Telemedicine adoption increased by 31% CAGR, exceeding national average</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}