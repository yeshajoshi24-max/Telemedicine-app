import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Heart, Users, Building2, Stethoscope, Pill } from 'lucide-react';

interface LoginPageProps {
  onLogin: (userType: string, userData: any) => void;
}

const portalConfigs = {
  patient: {
    title: 'Rural Patients Portal',
    icon: Users,
    colors: 'bg-blue-50 border-blue-200',
    buttonColors: 'bg-blue-600 hover:bg-blue-700',
    description: 'Access healthcare from your village'
  },
  hospital: {
    title: 'Civil Hospital Staff',
    icon: Building2,
    colors: 'bg-red-50 border-red-200',
    buttonColors: 'bg-red-600 hover:bg-red-700',
    description: 'Medical staff dashboard'
  },
  asha: {
    title: 'ASHA Workers',
    icon: Heart,
    colors: 'bg-orange-50 border-orange-200',
    buttonColors: 'bg-orange-600 hover:bg-orange-700',
    description: 'Community health workers'
  },
  health_dept: {
    title: 'Punjab Health Department',
    icon: Stethoscope,
    colors: 'bg-green-50 border-green-200',
    buttonColors: 'bg-green-600 hover:bg-green-700',
    description: 'Government health oversight'
  },
  pharmacy: {
    title: 'Local Pharmacies',
    icon: Pill,
    colors: 'bg-purple-50 border-purple-200',
    buttonColors: 'bg-purple-600 hover:bg-purple-700',
    description: 'Medicine inventory management'
  }
};

export function LoginPage({ onLogin }: LoginPageProps) {
  const [selectedPortal, setSelectedPortal] = useState<string>('');
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    userType: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPortal) return;

    setLoading(true);
    
    try {
      // Demo login - accept any email/password for testing
      const userData = {
        id: crypto.randomUUID(),
        email: formData.email,
        name: formData.name || 'Demo User',
        userType: selectedPortal,
        accessToken: 'demo-token-' + Date.now()
      };

      // Store in localStorage for persistence
      localStorage.setItem('nabha_user', JSON.stringify(userData));
      
      onLogin(selectedPortal, userData);
    } catch (error) {
      console.error('Authentication error:', error);
      alert('Authentication failed: ' + (error.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  if (!selectedPortal) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
        <div className="max-w-6xl w-full">
          <div className="text-center mb-8">
            <h1 className="text-4xl mb-4">नभा स्वास्थ्य सेवा</h1>
            <h2 className="text-3xl text-gray-600 mb-2">Nabha Healthcare Platform</h2>
            <p className="text-gray-600">Connecting rural communities with quality healthcare</p>
          </div>
          
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6 mb-8 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <h3 className="font-medium text-blue-800">🚀 Demo Mode Active - Nabha Healthcare Platform</h3>
            </div>
            <p className="text-sm text-blue-700 mb-4">
              Testing the comprehensive telemedicine solution for Nabha's 173 rural villages. 
              <br />
              <span className="font-medium">Enter any email and password to access different portals:</span>
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              <div className="bg-white/60 p-3 rounded-md border border-blue-100">
                <div className="flex items-center gap-2 mb-1">
                  <Heart className="w-4 h-4 text-blue-600" />
                  <strong className="text-blue-800">Patient Portal</strong>
                </div>
                <p className="text-xs text-blue-600">Book appointments, check records</p>
              </div>
              <div className="bg-white/60 p-3 rounded-md border border-red-100">
                <div className="flex items-center gap-2 mb-1">
                  <Stethoscope className="w-4 h-4 text-red-600" />
                  <strong className="text-red-800">Hospital Staff</strong>
                </div>
                <p className="text-xs text-red-600">Manage patients, schedules</p>
              </div>
              <div className="bg-white/60 p-3 rounded-md border border-orange-100">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-4 h-4 text-orange-600" />
                  <strong className="text-orange-800">ASHA Worker</strong>
                </div>
                <p className="text-xs text-orange-600">Community health screening</p>
              </div>
              <div className="bg-white/60 p-3 rounded-md border border-green-100">
                <div className="flex items-center gap-2 mb-1">
                  <Building2 className="w-4 h-4 text-green-600" />
                  <strong className="text-green-800">Health Department</strong>
                </div>
                <p className="text-xs text-green-600">Regional oversight, policies</p>
              </div>
              <div className="bg-white/60 p-3 rounded-md border border-purple-100">
                <div className="flex items-center gap-2 mb-1">
                  <Pill className="w-4 h-4 text-purple-600" />
                  <strong className="text-purple-800">Pharmacy</strong>
                </div>
                <p className="text-xs text-purple-600">Medicine inventory, availability</p>
              </div>
              <div className="bg-white/60 p-3 rounded-md border border-blue-100 flex items-center justify-center">
                <p className="text-xs text-blue-600 text-center">
                  <strong>All portals:</strong><br />
                  Any email/password works
                </p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(portalConfigs).map(([key, config]) => {
              const Icon = config.icon;
              return (
                <Card 
                  key={key}
                  className={`${config.colors} cursor-pointer hover:shadow-lg transition-all duration-200 transform hover:-translate-y-1`}
                  onClick={() => setSelectedPortal(key)}
                >
                  <CardHeader className="text-center">
                    <Icon className="w-12 h-12 mx-auto mb-4 text-gray-700" />
                    <CardTitle className="text-xl">{config.title}</CardTitle>
                    <p className="text-sm text-gray-600">{config.description}</p>
                  </CardHeader>
                  <CardContent>
                    <Button className={`w-full ${config.buttonColors}`}>
                      Enter Portal
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  const config = portalConfigs[selectedPortal];
  const Icon = config.icon;

  return (
    <div className={`min-h-screen ${config.colors} flex items-center justify-center p-4`}>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedPortal('')}
            className="absolute top-4 left-4"
          >
            ← Back
          </Button>
          <Icon className="w-12 h-12 mx-auto mb-4 text-gray-700" />
          <CardTitle>{config.title}</CardTitle>
          <p className="text-sm text-gray-600">{config.description}</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required={!isLogin}
                />
              </div>
            )}
            
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className={`w-full ${config.buttonColors}`}
              disabled={loading}
            >
              {loading ? 'Please wait...' : (isLogin ? 'Login' : 'Register')}
            </Button>
            
            <Button
              type="button"
              variant="ghost"
              className="w-full"
              onClick={() => setIsLogin(!isLogin)}
            >
              {isLogin ? 'Need an account? Register' : 'Already have an account? Login'}
            </Button>
          </form>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mt-4">
            <p className="text-xs text-yellow-700 text-center">🚀 Demo Mode: Any email/password works</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}