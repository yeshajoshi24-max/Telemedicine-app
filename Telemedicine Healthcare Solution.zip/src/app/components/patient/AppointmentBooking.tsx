import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Calendar, Clock, User } from 'lucide-react';

interface AppointmentBookingProps {
  user: any;
  onSuccess: () => void;
}

export function AppointmentBooking({ user, onSuccess }: AppointmentBookingProps) {
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [availability, setAvailability] = useState([]);
  const [formData, setFormData] = useState({
    date: '',
    time: '',
    symptoms: '',
    urgency: 'normal'
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDoctors();
  }, []);

  useEffect(() => {
    if (selectedDoctor) {
      fetchDoctorAvailability(selectedDoctor);
    }
  }, [selectedDoctor]);

  const fetchDoctors = async () => {
    try {
      const { projectId } = await import('../../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f2ba4e71/doctors`);
      const data = await response.json();
      setDoctors(data.doctors || []);
    } catch (error) {
      console.error('Failed to fetch doctors:', error);
    }
  };

  const fetchDoctorAvailability = async (doctorId: string) => {
    try {
      // For now, we'll create default availability for all doctors
      // In a real implementation, you would fetch this from the API
      const defaultTimeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];
      const next14Days = [];
      
      for (let i = 1; i <= 14; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        const dateString = date.toISOString().split('T')[0];
        
        next14Days.push({
          date: dateString,
          available: true,
          timeSlots: defaultTimeSlots
        });
      }
      
      setAvailability(next14Days);
    } catch (error) {
      console.error('Failed to fetch availability:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoctor || !formData.date || !formData.time) {
      alert('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      const { projectId } = await import('../../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f2ba4e71/appointments/book`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify({
          doctorId: selectedDoctor,
          ...formData
        }),
      });

      const result = await response.json();
      if (result.success) {
        alert('Appointment booked successfully!');
        setFormData({ date: '', time: '', symptoms: '', urgency: 'normal' });
        setSelectedDoctor('');
        onSuccess();
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Booking failed:', error);
      alert('Failed to book appointment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getAvailableSlots = (date: string) => {
    const dayAvailability = availability.find((avail: any) => avail.date === date);
    return dayAvailability?.available ? dayAvailability.timeSlots || [] : [];
  };

  // Generate next 14 days for date selection
  const getAvailableDates = () => {
    const dates = [];
    for (let i = 1; i <= 14; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const dateString = date.toISOString().split('T')[0];
      dates.push({
        value: dateString,
        label: date.toLocaleDateString('en-IN', { 
          weekday: 'short', 
          month: 'short', 
          day: 'numeric' 
        })
      });
    }
    return dates;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800">
            <Calendar className="w-5 h-5 mr-2" />
            Book New Appointment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Doctor Selection */}
            <div>
              <Label>Select Doctor</Label>
              <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a doctor" />
                </SelectTrigger>
                <SelectContent>
                  {doctors.map((doctor) => (
                    <SelectItem key={doctor.id} value={doctor.id}>
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-2" />
                        Dr. {doctor.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date Selection */}
            <div>
              <Label>Select Date</Label>
              <Select value={formData.date} onValueChange={(value) => setFormData(prev => ({ ...prev, date: value, time: '' }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose appointment date" />
                </SelectTrigger>
                <SelectContent>
                  {getAvailableDates().map((date) => (
                    <SelectItem key={date.value} value={date.value}>
                      {date.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Time Selection */}
            {formData.date && (
              <div>
                <Label>Available Time Slots</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {getAvailableSlots(formData.date).map((slot) => (
                    <Button
                      key={slot}
                      type="button"
                      variant={formData.time === slot ? 'default' : 'outline'}
                      onClick={() => setFormData(prev => ({ ...prev, time: slot }))}
                      className={formData.time === slot ? 'bg-blue-600 hover:bg-blue-700' : ''}
                    >
                      <Clock className="w-4 h-4 mr-1" />
                      {slot}
                    </Button>
                  ))}
                </div>
                {getAvailableSlots(formData.date).length === 0 && (
                  <p className="text-gray-500 text-sm mt-2">No slots available for this date</p>
                )}
              </div>
            )}

            {/* Symptoms */}
            <div>
              <Label htmlFor="symptoms">Describe your symptoms</Label>
              <Textarea
                id="symptoms"
                value={formData.symptoms}
                onChange={(e) => setFormData(prev => ({ ...prev, symptoms: e.target.value }))}
                placeholder="Please describe your health concerns in detail..."
                className="min-h-[100px]"
                required
              />
            </div>

            {/* Urgency */}
            <div>
              <Label>Urgency Level</Label>
              <Select value={formData.urgency} onValueChange={(value) => setFormData(prev => ({ ...prev, urgency: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">
                    <Badge variant="secondary">Low - Routine checkup</Badge>
                  </SelectItem>
                  <SelectItem value="normal">
                    <Badge variant="default">Normal - Regular concern</Badge>
                  </SelectItem>
                  <SelectItem value="high">
                    <Badge variant="destructive">High - Urgent attention needed</Badge>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={loading || !selectedDoctor || !formData.date || !formData.time}
            >
              {loading ? 'Booking...' : 'Book Appointment'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800">Important Instructions</CardTitle>
        </CardHeader>
        <CardContent className="text-blue-700">
          <ul className="space-y-2">
            <li>• Please be available 5 minutes before your appointment time</li>
            <li>• Ensure you have a stable internet connection for video consultation</li>
            <li>• Keep your previous medical records handy</li>
            <li>• You will receive a video call link via SMS</li>
            <li>• For emergency situations, please visit the hospital directly</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}