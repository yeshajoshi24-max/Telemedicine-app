import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { FileText, Download, Calendar, User } from 'lucide-react';

interface HealthRecordsProps {
  user: any;
}

export function HealthRecords({ user }: HealthRecordsProps) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHealthRecords();
  }, []);

  const fetchHealthRecords = async () => {
    try {
      const response = await fetch(`https://${process.env.SUPABASE_URL?.split('//')[1]}/functions/v1/make-server-f2ba4e71/health-records/${user.id}`);
      const data = await response.json();
      setRecords(data.records || []);
    } catch (error) {
      console.error('Failed to fetch health records:', error);
    } finally {
      setLoading(false);
    }
  };

  const downloadRecord = (record: any) => {
    const recordText = `
HEALTH RECORD
=============

Patient: ${user.name}
Date: ${new Date(record.createdAt).toLocaleDateString()}
Doctor: Dr. ${record.doctorName || 'Unknown'}

DIAGNOSIS:
${record.diagnosis}

PRESCRIPTION:
${record.prescription}

NOTES:
${record.notes}

---
Generated from Nabha Healthcare Platform
    `;

    const blob = new Blob([recordText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `health-record-${new Date(record.createdAt).toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800">
            <FileText className="w-5 h-5 mr-2" />
            Digital Health Records
          </CardTitle>
          <p className="text-sm text-gray-600">
            Your complete medical history is stored securely and accessible offline
          </p>
        </CardHeader>
      </Card>

      {records.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-600 mb-2">No Health Records Yet</h3>
            <p className="text-gray-500">
              Your health records will appear here after your first consultation with a doctor.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {records.map((record, index) => (
            <Card key={record.id || index} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <div>
                      <h3 className="font-medium">
                        {new Date(record.createdAt).toLocaleDateString('en-IN', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </h3>
                      <p className="text-sm text-gray-600 flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        Dr. {record.doctorName || 'Unknown Doctor'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => downloadRecord(record)}
                    className="flex items-center text-blue-600 hover:text-blue-700 text-sm"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-700 mb-1">Diagnosis</h4>
                  <p className="text-gray-600">{record.diagnosis}</p>
                </div>

                <div>
                  <h4 className="font-medium text-gray-700 mb-1">Prescription</h4>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-blue-800">{record.prescription}</p>
                  </div>
                </div>

                {record.notes && (
                  <div>
                    <h4 className="font-medium text-gray-700 mb-1">Doctor's Notes</h4>
                    <p className="text-gray-600">{record.notes}</p>
                  </div>
                )}

                <div className="pt-2 border-t border-gray-100">
                  <Badge variant="secondary" className="text-xs">
                    Record ID: {record.id}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Offline Storage Info */}
      <Card className="bg-green-50 border-green-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <div className="bg-green-100 p-2 rounded-full">
              <FileText className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-medium text-green-800">Offline Access Available</h3>
              <p className="text-sm text-green-700 mt-1">
                Your health records are cached locally and can be accessed even without internet connection. 
                Downloaded records can be shared with other healthcare providers when needed.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}