import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { Badge } from '../ui/badge';
import { AlertTriangle, CheckCircle, Info, Brain } from 'lucide-react';

interface SymptomCheckerProps {
  user: any;
}

const commonSymptoms = [
  'Fever', 'Headache', 'Cough', 'Sore throat', 'Body ache', 'Fatigue',
  'Nausea', 'Vomiting', 'Diarrhea', 'Stomach pain', 'Chest pain',
  'Difficulty breathing', 'Dizziness', 'Rash', 'Joint pain'
];

const symptomDatabase = {
  'fever,headache,body ache': {
    condition: 'Viral Fever',
    risk: 'low',
    advice: 'Rest, drink plenty of fluids, and take paracetamol for fever. Consult doctor if symptoms persist for more than 3 days.',
    urgency: 'Monitor at home'
  },
  'cough,sore throat,fever': {
    condition: 'Upper Respiratory Infection',
    risk: 'low',
    advice: 'Gargle with warm salt water, take steam inhalation, and rest. Avoid cold foods.',
    urgency: 'Home care recommended'
  },
  'chest pain,difficulty breathing': {
    condition: 'Requires Immediate Medical Attention',
    risk: 'high',
    advice: 'Seek immediate medical care. These symptoms could indicate serious conditions.',
    urgency: 'Emergency - Visit hospital immediately'
  },
  'nausea,vomiting,stomach pain': {
    condition: 'Gastroenteritis',
    risk: 'medium',
    advice: 'Stay hydrated with ORS, eat light foods like rice and curd. Avoid spicy and oily foods.',
    urgency: 'Consult doctor if severe'
  },
  'dizziness,fatigue,headache': {
    condition: 'Possible Anemia or Dehydration',
    risk: 'medium',
    advice: 'Increase iron-rich foods, drink more water, and get adequate rest. Blood test recommended.',
    urgency: 'Schedule routine appointment'
  }
};

export function SymptomChecker({ user }: SymptomCheckerProps) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [customSymptom, setCustomSymptom] = useState('');
  const [duration, setDuration] = useState('');
  const [severity, setSeverity] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleSymptomToggle = (symptom: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptom) 
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
  };

  const addCustomSymptom = () => {
    if (customSymptom && !selectedSymptoms.includes(customSymptom)) {
      setSelectedSymptoms(prev => [...prev, customSymptom]);
      setCustomSymptom('');
    }
  };

  const analyzeSymptoms = () => {
    setLoading(true);
    
    // Simulate AI analysis delay
    setTimeout(() => {
      const symptomsKey = selectedSymptoms.map(s => s.toLowerCase()).sort().join(',');
      
      // Check for exact matches first
      let analysis = symptomDatabase[symptomsKey];
      
      // If no exact match, check for partial matches
      if (!analysis) {
        for (const [key, value] of Object.entries(symptomDatabase)) {
          const keySymptoms = key.split(',');
          const matchCount = keySymptoms.filter(s => 
            selectedSymptoms.some(selected => selected.toLowerCase().includes(s))
          ).length;
          
          if (matchCount >= 2) {
            analysis = value;
            break;
          }
        }
      }

      // Default analysis if no matches
      if (!analysis) {
        analysis = {
          condition: 'General Health Concern',
          risk: 'medium',
          advice: 'Your symptoms require medical evaluation. Please consult with a doctor for proper diagnosis.',
          urgency: 'Schedule appointment soon'
        };
      }

      // Adjust risk based on severity and duration
      if (severity === 'severe' || selectedSymptoms.includes('Chest pain') || selectedSymptoms.includes('Difficulty breathing')) {
        analysis.risk = 'high';
        analysis.urgency = 'Seek immediate medical attention';
      }

      setResult({
        ...analysis,
        symptoms: selectedSymptoms,
        duration,
        severity,
        timestamp: new Date().toLocaleString()
      });
      setLoading(false);
    }, 2000);
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'low': return <CheckCircle className="w-5 h-5" />;
      case 'medium': return <Info className="w-5 h-5" />;
      case 'high': return <AlertTriangle className="w-5 h-5" />;
      default: return <Info className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800">
            <Brain className="w-5 h-5 mr-2" />
            AI Symptom Checker
          </CardTitle>
          <p className="text-sm text-gray-600">
            This tool provides general guidance only and is not a substitute for professional medical advice.
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Symptom Selection */}
          <div>
            <Label className="text-base">Select your symptoms:</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
              {commonSymptoms.map((symptom) => (
                <div key={symptom} className="flex items-center space-x-2">
                  <Checkbox
                    id={symptom}
                    checked={selectedSymptoms.includes(symptom)}
                    onCheckedChange={() => handleSymptomToggle(symptom)}
                  />
                  <Label htmlFor={symptom} className="text-sm">{symptom}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Symptom */}
          <div>
            <Label htmlFor="custom">Add other symptoms:</Label>
            <div className="flex space-x-2 mt-2">
              <Input
                id="custom"
                value={customSymptom}
                onChange={(e) => setCustomSymptom(e.target.value)}
                placeholder="Describe any other symptoms..."
              />
              <Button onClick={addCustomSymptom} variant="outline">Add</Button>
            </div>
          </div>

          {/* Selected Symptoms */}
          {selectedSymptoms.length > 0 && (
            <div>
              <Label>Selected symptoms:</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {selectedSymptoms.map((symptom) => (
                  <Badge key={symptom} variant="secondary" className="cursor-pointer" onClick={() => handleSymptomToggle(symptom)}>
                    {symptom} ×
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Duration and Severity */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="duration">How long have you had these symptoms?</Label>
              <select 
                id="duration"
                className="w-full p-2 border rounded-md mt-1"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
              >
                <option value="">Select duration</option>
                <option value="few hours">Few hours</option>
                <option value="1 day">1 day</option>
                <option value="2-3 days">2-3 days</option>
                <option value="1 week">1 week</option>
                <option value="more than week">More than a week</option>
              </select>
            </div>

            <div>
              <Label htmlFor="severity">How severe are your symptoms?</Label>
              <select 
                id="severity"
                className="w-full p-2 border rounded-md mt-1"
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
              >
                <option value="">Select severity</option>
                <option value="mild">Mild - Manageable</option>
                <option value="moderate">Moderate - Uncomfortable</option>
                <option value="severe">Severe - Very bothersome</option>
              </select>
            </div>
          </div>

          {/* Analyze Button */}
          <Button 
            onClick={analyzeSymptoms}
            disabled={selectedSymptoms.length === 0 || loading}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {loading ? 'Analyzing symptoms...' : 'Analyze Symptoms'}
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {result && (
        <Card className={`border-2 ${getRiskColor(result.risk)}`}>
          <CardHeader>
            <CardTitle className={`flex items-center ${getRiskColor(result.risk).split(' ')[0]}`}>
              {getRiskIcon(result.risk)}
              <span className="ml-2">Analysis Result</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-base">Possible Condition:</Label>
              <p className="text-lg font-medium">{result.condition}</p>
            </div>

            <div>
              <Label className="text-base">Recommendation:</Label>
              <p>{result.advice}</p>
            </div>

            <div>
              <Label className="text-base">Next Steps:</Label>
              <p className="font-medium">{result.urgency}</p>
            </div>

            <div className="pt-4 border-t">
              <p className="text-sm text-gray-600">
                Analysis based on: {result.symptoms.join(', ')} | 
                Duration: {result.duration} | 
                Severity: {result.severity}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Generated on: {result.timestamp}
              </p>
            </div>

            {result.risk === 'high' && (
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                <p className="text-red-700 font-medium">⚠️ Important: This appears to be a serious condition requiring immediate medical attention.</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Disclaimer */}
      <Card className="bg-gray-50 border-gray-200">
        <CardContent className="pt-6">
          <p className="text-sm text-gray-600 text-center">
            <strong>Medical Disclaimer:</strong> This symptom checker is for informational purposes only and does not replace professional medical advice. 
            Always consult with qualified healthcare providers for accurate diagnosis and treatment.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}