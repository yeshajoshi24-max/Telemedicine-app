import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Calendar, Clock, Video, FileText, Search, MessageCircle, LogOut } from 'lucide-react';
import { AppointmentBooking } from './AppointmentBooking';
import { SymptomChecker } from './SymptomChecker';
import { HealthRecords } from './HealthRecords';
import { MedicineSearch } from './MedicineSearch';

interface PatientDashboardProps {
  user: any;
  onLogout: () => void;
}

export function PatientDashboard({ user, onLogout }: PatientDashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const { projectId } = await import('../../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f2ba4e71/appointments/patient`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
        },
      });
      const data = await response.json();
      setAppointments(data.appointments || []);
    } catch (error) {
      console.error('Failed to fetch appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'book':
        return <AppointmentBooking user={user} onSuccess={fetchAppointments} />;
      case 'symptoms':
        return <SymptomChecker user={user} />;
      case 'records':
        return <HealthRecords user={user} />;
      case 'medicine':
        return <MedicineSearch />;
      default:
        return (
          <div className="space-y-6">
            {/* Welcome Section */}
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">नमस्ते, {user.name}!</CardTitle>
                <p className="text-blue-600">Welcome to your health dashboard</p>
              </CardHeader>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('book')}>
                <CardHeader className="text-center">
                  <Calendar className="w-8 h-8 mx-auto text-blue-600" />
                  <CardTitle className="text-lg">Book Appointment</CardTitle>
                  <p className="text-sm text-gray-600">Schedule with doctors</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('symptoms')}>
                <CardHeader className="text-center">
                  <MessageCircle className="w-8 h-8 mx-auto text-blue-600" />
                  <CardTitle className="text-lg">Symptom Checker</CardTitle>
                  <p className="text-sm text-gray-600">AI-powered assessment</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('records')}>
                <CardHeader className="text-center">
                  <FileText className="w-8 h-8 mx-auto text-blue-600" />
                  <CardTitle className="text-lg">Health Records</CardTitle>
                  <p className="text-sm text-gray-600">View your history</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('medicine')}>
                <CardHeader className="text-center">
                  <Search className="w-8 h-8 mx-auto text-blue-600" />
                  <CardTitle className="text-lg">Find Medicine</CardTitle>
                  <p className="text-sm text-gray-600">Check availability</p>
                </CardHeader>
              </Card>
            </div>

            {/* Recent Appointments */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Appointments</CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <p>Loading appointments...</p>
                ) : appointments.length === 0 ? (
                  <p className="text-gray-600">No appointments yet. Book your first appointment!</p>
                ) : (
                  <div className="space-y-3">
                    {appointments.slice(0, 5).map((apt, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium">Dr. {apt.doctorName || 'Unknown'}</p>
                          <p className="text-sm text-gray-600">{apt.date} at {apt.time}</p>
                          <p className="text-sm text-gray-500">{apt.symptoms}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant={apt.status === 'scheduled' ? 'default' : 'secondary'}>
                            {apt.status}
                          </Badge>
                          {apt.status === 'scheduled' && (
                            <Button size="sm" className="mt-1 bg-blue-600 hover:bg-blue-700">
                              <Video className="w-4 h-4 mr-1" />
                              Join Call
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Health Tips */}
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800">Daily Health Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-green-700">
                  <li>• Drink at least 8 glasses of water daily</li>
                  <li>• Take a 30-minute walk every day</li>
                  <li>• Eat fresh fruits and vegetables</li>
                  <li>• Get 7-8 hours of sleep</li>
                  <li>• Wash hands frequently</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-blue-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-blue-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-xl text-blue-800">Rural Patient Portal</h1>
              <div className="hidden md:flex space-x-4">
                <Button 
                  variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('dashboard')}
                  className={activeTab === 'dashboard' ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === 'book' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('book')}
                  className={activeTab === 'book' ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  Book Appointment
                </Button>
                <Button 
                  variant={activeTab === 'symptoms' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('symptoms')}
                  className={activeTab === 'symptoms' ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  Symptom Checker
                </Button>
                <Button 
                  variant={activeTab === 'records' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('records')}
                  className={activeTab === 'records' ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  Health Records
                </Button>
                <Button 
                  variant={activeTab === 'medicine' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('medicine')}
                  className={activeTab === 'medicine' ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  Find Medicine
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button variant="outline" onClick={onLogout} className="border-blue-300 text-blue-700 hover:bg-blue-50">
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}