import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Search, MapPin, Phone, Clock, CheckCircle, XCircle } from 'lucide-react';

export function MedicineSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(`https://${process.env.SUPABASE_URL?.split('//')[1]}/functions/v1/make-server-f2ba4e71/medicine/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      setSearchResults(data.medicines || []);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStockStatus = (stock: number) => {
    if (stock > 10) return { status: 'In Stock', color: 'text-green-600', icon: CheckCircle };
    if (stock > 0) return { status: 'Low Stock', color: 'text-yellow-600', icon: CheckCircle };
    return { status: 'Out of Stock', color: 'text-red-600', icon: XCircle };
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800">
            <Search className="w-5 h-5 mr-2" />
            Medicine Availability Search
          </CardTitle>
          <p className="text-sm text-gray-600">
            Find medicines available at local pharmacies in real-time
          </p>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for medicine (e.g., Paracetamol, Crocin, etc.)"
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button 
              onClick={handleSearch}
              disabled={loading || !searchQuery.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? 'Searching...' : 'Search'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-800">
            Search Results for "{searchQuery}"
          </h3>
          
          {searchResults.map((medicine, index) => {
            const stockInfo = getStockStatus(medicine.stock);
            const StockIcon = stockInfo.icon;
            
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-medium">{medicine.name}</h3>
                        <Badge variant="outline">{medicine.type}</Badge>
                        <div className={`flex items-center space-x-1 ${stockInfo.color}`}>
                          <StockIcon className="w-4 h-4" />
                          <span className="text-sm font-medium">{stockInfo.status}</span>
                        </div>
                      </div>
                      
                      <p className="text-gray-600 mb-3">{medicine.description}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Price:</p>
                          <p className="font-medium">₹{medicine.price}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Stock Available:</p>
                          <p className="font-medium">{medicine.stock} units</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right ml-4">
                      <p className="text-lg font-bold">₹{medicine.price}</p>
                      <p className="text-sm text-gray-500">{medicine.stock} in stock</p>
                    </div>
                  </div>
                  
                  {/* Pharmacy Details */}
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          <span>Pharmacy Near Civil Hospital</span>
                        </div>
                        <div className="flex items-center">
                          <Phone className="w-4 h-4 mr-1" />
                          <span>+91 98765 43210</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          <span>9 AM - 9 PM</span>
                        </div>
                      </div>
                      
                      {medicine.stock > 0 && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          Reserve Medicine
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {searchQuery && searchResults.length === 0 && !loading && (
        <Card className="text-center py-12">
          <CardContent>
            <Search className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-600 mb-2">No medicines found</h3>
            <p className="text-gray-500">
              Try searching with a different medicine name or check the spelling.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Common Medicines */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800">Commonly Searched Medicines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[
              'Paracetamol', 'Crocin', 'Aspirin', 'Ibuprofen',
              'Cough Syrup', 'Antibiotics', 'Vitamin D', 'Iron Tablets'
            ].map((medicine) => (
              <Button
                key={medicine}
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchQuery(medicine);
                  setTimeout(handleSearch, 100);
                }}
                className="justify-start"
              >
                {medicine}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardContent className="pt-6">
          <h3 className="font-medium text-yellow-800 mb-2">Important Information</h3>
          <ul className="text-sm text-yellow-700 space-y-1">
            <li>• Medicine availability is updated in real-time</li>
            <li>• Prices may vary slightly between pharmacies</li>
            <li>• Reserve medicines to ensure availability when you visit</li>
            <li>• Always carry your prescription when buying medicines</li>
            <li>• Call the pharmacy to confirm availability before traveling</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}