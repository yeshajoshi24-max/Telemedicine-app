import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Package, Plus, Search, AlertTriangle, Edit, Save } from 'lucide-react';

interface InventoryManagementProps {
  user: any;
}

export function InventoryManagement({ user }: InventoryManagementProps) {
  const [medicines, setMedicines] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMedicine, setNewMedicine] = useState({
    name: '',
    type: '',
    price: '',
    stock: '',
    description: '',
    expiryDate: '',
    manufacturer: ''
  });

  // Sample medicine data
  useEffect(() => {
    setMedicines([
      {
        id: 1,
        name: 'Paracetamol 500mg',
        type: 'Tablet',
        price: 2.50,
        stock: 12,
        description: 'Pain relief and fever reducer',
        expiryDate: '2025-06-15',
        manufacturer: 'Generic Pharma'
      },
      {
        id: 2,
        name: 'Crocin 650mg',
        type: 'Tablet',
        price: 3.20,
        stock: 23,
        description: 'Fast relief from headache and fever',
        expiryDate: '2025-03-20',
        manufacturer: 'GSK'
      },
      {
        id: 3,
        name: 'ORS Packets',
        type: 'Powder',
        price: 5.00,
        stock: 45,
        description: 'Oral rehydration solution',
        expiryDate: '2026-01-10',
        manufacturer: 'Cipla'
      },
      {
        id: 4,
        name: 'Amoxicillin 500mg',
        type: 'Capsule',
        price: 8.50,
        stock: 78,
        description: 'Antibiotic for bacterial infections',
        expiryDate: '2025-09-30',
        manufacturer: 'Sun Pharma'
      },
      {
        id: 5,
        name: 'Cough Syrup',
        type: 'Syrup',
        price: 45.00,
        stock: 34,
        description: 'Relief from dry and wet cough',
        expiryDate: '2025-08-25',
        manufacturer: 'Dabur'
      }
    ]);
  }, []);

  const filteredMedicines = medicines.filter(medicine => {
    const matchesSearch = medicine.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         medicine.manufacturer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || medicine.type === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getStockStatus = (stock) => {
    if (stock <= 10) return { status: 'Critical', color: 'bg-red-100 text-red-800' };
    if (stock <= 25) return { status: 'Low', color: 'bg-yellow-100 text-yellow-800' };
    if (stock <= 50) return { status: 'Medium', color: 'bg-blue-100 text-blue-800' };
    return { status: 'Good', color: 'bg-green-100 text-green-800' };
  };

  const handleEdit = (medicine) => {
    setEditingId(medicine.id);
    setEditData({ ...medicine });
  };

  const handleSave = async (medicineId) => {
    try {
      // Update medicine in backend
      const response = await fetch(`https://${process.env.SUPABASE_URL?.split('//')[1]}/functions/v1/make-server-f2ba4e71/medicine/inventory`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify({
          medicines: [editData]
        }),
      });

      if (response.ok) {
        // Update local state
        setMedicines(prev => prev.map(med => 
          med.id === medicineId ? { ...editData } : med
        ));
        setEditingId(null);
        setEditData({});
        alert('Medicine updated successfully!');
      }
    } catch (error) {
      console.error('Failed to update medicine:', error);
      alert('Failed to update medicine. Please try again.');
    }
  };

  const handleAddMedicine = async (e) => {
    e.preventDefault();
    try {
      const medicineWithId = {
        ...newMedicine,
        id: Date.now(),
        price: parseFloat(newMedicine.price),
        stock: parseInt(newMedicine.stock)
      };

      // Add to backend
      const response = await fetch(`https://${process.env.SUPABASE_URL?.split('//')[1]}/functions/v1/make-server-f2ba4e71/medicine/inventory`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify({
          medicines: [medicineWithId]
        }),
      });

      if (response.ok) {
        setMedicines(prev => [...prev, medicineWithId]);
        setNewMedicine({
          name: '',
          type: '',
          price: '',
          stock: '',
          description: '',
          expiryDate: '',
          manufacturer: ''
        });
        setShowAddForm(false);
        alert('Medicine added successfully!');
      }
    } catch (error) {
      console.error('Failed to add medicine:', error);
      alert('Failed to add medicine. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-purple-800">
                <Package className="w-5 h-5 mr-2" />
                Medicine Inventory Management
              </CardTitle>
              <p className="text-sm text-gray-600">
                Manage stock levels, prices, and medicine information
              </p>
            </div>
            <Button 
              onClick={() => setShowAddForm(!showAddForm)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Medicine
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Add Medicine Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Medicine</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddMedicine} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Medicine Name *</Label>
                  <Input
                    id="name"
                    value={newMedicine.name}
                    onChange={(e) => setNewMedicine(prev => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="type">Type *</Label>
                  <Select value={newMedicine.type} onValueChange={(value) => setNewMedicine(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Tablet">Tablet</SelectItem>
                      <SelectItem value="Capsule">Capsule</SelectItem>
                      <SelectItem value="Syrup">Syrup</SelectItem>
                      <SelectItem value="Injection">Injection</SelectItem>
                      <SelectItem value="Powder">Powder</SelectItem>
                      <SelectItem value="Cream">Cream</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="price">Price (₹) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={newMedicine.price}
                    onChange={(e) => setNewMedicine(prev => ({ ...prev, price: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="stock">Stock Quantity *</Label>
                  <Input
                    id="stock"
                    type="number"
                    value={newMedicine.stock}
                    onChange={(e) => setNewMedicine(prev => ({ ...prev, stock: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="expiryDate">Expiry Date *</Label>
                  <Input
                    id="expiryDate"
                    type="date"
                    value={newMedicine.expiryDate}
                    onChange={(e) => setNewMedicine(prev => ({ ...prev, expiryDate: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="manufacturer">Manufacturer *</Label>
                  <Input
                    id="manufacturer"
                    value={newMedicine.manufacturer}
                    onChange={(e) => setNewMedicine(prev => ({ ...prev, manufacturer: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={newMedicine.description}
                  onChange={(e) => setNewMedicine(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Brief description of the medicine"
                />
              </div>

              <div className="flex space-x-2">
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  Add Medicine
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search medicines..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Tablet">Tablets</SelectItem>
                  <SelectItem value="Capsule">Capsules</SelectItem>
                  <SelectItem value="Syrup">Syrups</SelectItem>
                  <SelectItem value="Injection">Injections</SelectItem>
                  <SelectItem value="Powder">Powders</SelectItem>
                  <SelectItem value="Cream">Creams</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-purple-700">
              <p>Total: {filteredMedicines.length} medicines</p>
              <p>Low Stock: {filteredMedicines.filter(m => m.stock <= 25).length} items</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Inventory List */}
      <div className="space-y-4">
        {filteredMedicines.map((medicine) => {
          const stockInfo = getStockStatus(medicine.stock);
          const isEditing = editingId === medicine.id;
          
          return (
            <Card key={medicine.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    {isEditing ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <Label>Medicine Name</Label>
                            <Input
                              value={editData.name || ''}
                              onChange={(e) => setEditData(prev => ({ ...prev, name: e.target.value }))}
                            />
                          </div>
                          <div>
                            <Label>Price (₹)</Label>
                            <Input
                              type="number"
                              step="0.01"
                              value={editData.price || ''}
                              onChange={(e) => setEditData(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                            />
                          </div>
                          <div>
                            <Label>Stock</Label>
                            <Input
                              type="number"
                              value={editData.stock || ''}
                              onChange={(e) => setEditData(prev => ({ ...prev, stock: parseInt(e.target.value) }))}
                            />
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" onClick={() => handleSave(medicine.id)} className="bg-green-600 hover:bg-green-700">
                            <Save className="w-4 h-4 mr-1" />
                            Save
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditingId(null)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-medium">{medicine.name}</h3>
                          <Badge variant="outline">{medicine.type}</Badge>
                          <Badge className={stockInfo.color}>
                            {stockInfo.status}
                          </Badge>
                          {medicine.stock <= 10 && (
                            <AlertTriangle className="w-5 h-5 text-red-500" />
                          )}
                        </div>

                        <p className="text-gray-600 mb-3">{medicine.description}</p>

                        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Price:</span>
                            <p className="font-medium">₹{medicine.price}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Stock:</span>
                            <p className="font-medium">{medicine.stock} units</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Expiry:</span>
                            <p className="font-medium">{new Date(medicine.expiryDate).toLocaleDateString()}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Manufacturer:</span>
                            <p className="font-medium">{medicine.manufacturer}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Medicine ID:</span>
                            <p className="font-medium">MED-{medicine.id}</p>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  {!isEditing && (
                    <div className="ml-4 space-y-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(medicine)}>
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      {medicine.stock <= 25 && (
                        <Button size="sm" className="bg-orange-600 hover:bg-orange-700 w-full">
                          Reorder
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Stock Summary */}
      <Card className="bg-purple-50 border-purple-200">
        <CardHeader>
          <CardTitle className="text-purple-800">Inventory Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <h3 className="text-2xl font-bold text-green-700">
                {medicines.filter(m => m.stock > 50).length}
              </h3>
              <p className="text-sm text-green-600">Well Stocked</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-blue-700">
                {medicines.filter(m => m.stock > 25 && m.stock <= 50).length}
              </h3>
              <p className="text-sm text-blue-600">Medium Stock</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-yellow-700">
                {medicines.filter(m => m.stock > 10 && m.stock <= 25).length}
              </h3>
              <p className="text-sm text-yellow-600">Low Stock</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-red-700">
                {medicines.filter(m => m.stock <= 10).length}
              </h3>
              <p className="text-sm text-red-600">Critical Stock</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}