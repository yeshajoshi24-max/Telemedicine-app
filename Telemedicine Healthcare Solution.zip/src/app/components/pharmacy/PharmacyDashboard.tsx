import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Pill, Package, TrendingUp, AlertTriangle, Users, LogOut, Clock, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { InventoryManagement } from './InventoryManagement';

interface PharmacyDashboardProps {
  user: any;
  onLogout: () => void;
}

const OrderTrackingView = () => {
  const [orders, setOrders] = useState([
    {
      id: '#ORD-1247',
      customerName: 'Rajesh Kumar',
      items: ['Paracetamol 500mg', 'Cough Syrup', 'Vitamin D'],
      amount: 245,
      status: 'completed',
      time: '2 hours ago',
      prescription: true
    },
    {
      id: '#ORD-1248',
      customerName: 'Sunita Devi',
      items: ['Iron tablets', 'Folic acid'],
      amount: 89,
      status: 'preparing',
      time: '1 hour ago',
      prescription: false
    },
    {
      id: '#ORD-1249',
      customerName: 'Mohan Singh',
      items: ['Diabetes medication', 'BP tablets'],
      amount: 567,
      status: 'pending',
      time: '30 min ago',
      prescription: true
    },
    {
      id: '#ORD-1250',
      customerName: 'Priya Sharma',
      items: ['Antibiotics', 'Probiotics'],
      amount: 345,
      status: 'ready',
      time: '15 min ago',
      prescription: true
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-600';
      case 'ready': return 'bg-blue-600';
      case 'preparing': return 'bg-yellow-600';
      case 'pending': return 'bg-orange-600';
      case 'cancelled': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'ready': return <Package className="w-4 h-4" />;
      case 'preparing': return <RefreshCw className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'cancelled': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const updateOrderStatus = (orderId: string, newStatus: string) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-purple-800 flex items-center">
            <Package className="w-5 h-5 mr-2" />
            Order Management & Tracking
          </CardTitle>
          <p className="text-sm text-gray-600">Manage customer orders and prescriptions</p>
        </CardHeader>
      </Card>

      {/* Order Status Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center">
          <CardContent className="pt-6">
            <Clock className="w-8 h-8 mx-auto text-orange-600 mb-2" />
            <h3 className="text-2xl font-bold">8</h3>
            <p className="text-sm text-gray-600">Pending Orders</p>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="pt-6">
            <RefreshCw className="w-8 h-8 mx-auto text-yellow-600 mb-2" />
            <h3 className="text-2xl font-bold">5</h3>
            <p className="text-sm text-gray-600">Preparing</p>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="pt-6">
            <Package className="w-8 h-8 mx-auto text-blue-600 mb-2" />
            <h3 className="text-2xl font-bold">12</h3>
            <p className="text-sm text-gray-600">Ready for Pickup</p>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="pt-6">
            <CheckCircle className="w-8 h-8 mx-auto text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">89</h3>
            <p className="text-sm text-gray-600">Completed Today</p>
          </CardContent>
        </Card>
      </div>

      {/* Orders List */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-lg">{order.id} - {order.customerName}</h4>
                    <p className="text-sm text-gray-600">{order.time}</p>
                    {order.prescription && (
                      <Badge className="bg-blue-100 text-blue-800 mt-1">Prescription Required</Badge>
                    )}
                  </div>
                  <div className="text-right">
                    <Badge className={`${getStatusColor(order.status)} flex items-center gap-1 mb-2`}>
                      {getStatusIcon(order.status)}
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </Badge>
                    <p className="text-lg font-semibold">₹{order.amount}</p>
                  </div>
                </div>
                
                <div className="mb-3">
                  <p className="text-sm text-gray-700 mb-1">Items:</p>
                  <p className="text-sm">{order.items.join(', ')}</p>
                </div>

                <div className="flex gap-2">
                  {order.status === 'pending' && (
                    <Button 
                      size="sm" 
                      onClick={() => updateOrderStatus(order.id, 'preparing')}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      Start Preparing
                    </Button>
                  )}
                  {order.status === 'preparing' && (
                    <Button 
                      size="sm" 
                      onClick={() => updateOrderStatus(order.id, 'ready')}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Mark Ready
                    </Button>
                  )}
                  {order.status === 'ready' && (
                    <Button 
                      size="sm" 
                      onClick={() => updateOrderStatus(order.id, 'completed')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Complete Order
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const SalesAnalyticsView = () => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-purple-800 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Sales Analytics & Reports
          </CardTitle>
          <p className="text-sm text-gray-600">Track sales performance and business insights</p>
        </CardHeader>
      </Card>

      {/* Sales Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Today's Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Total Revenue</span>
                <span className="text-xl font-bold text-green-600">₹45,678</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Orders</span>
                <span className="font-semibold">156</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Average Order</span>
                <span className="font-semibold">₹293</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">This Week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Total Revenue</span>
                <span className="text-xl font-bold text-blue-600">₹2,89,456</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Orders</span>
                <span className="font-semibold">987</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Growth</span>
                <span className="font-semibold text-green-600">+12.5%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Total Revenue</span>
                <span className="text-xl font-bold text-purple-600">₹8,45,678</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Orders</span>
                <span className="font-semibold">2,847</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Net Profit</span>
                <span className="font-semibold text-green-600">₹2,34,567</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Selling Medicines */}
      <Card>
        <CardHeader>
          <CardTitle>Top Selling Medicines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: 'Paracetamol 500mg', sold: 234, revenue: 11700, trend: '+5%' },
              { name: 'Crocin 650mg', sold: 189, revenue: 15120, trend: '+12%' },
              { name: 'ORS Packets', sold: 156, revenue: 4680, trend: '+8%' },
              { name: 'Vitamin D tablets', sold: 134, revenue: 20100, trend: '+15%' },
              { name: 'Cough Syrup', sold: 98, revenue: 9800, trend: '-2%' }
            ].map((medicine, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-medium">{medicine.name}</h4>
                  <p className="text-sm text-gray-600">{medicine.sold} units sold</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">₹{medicine.revenue.toLocaleString()}</p>
                  <p className={`text-sm ${medicine.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                    {medicine.trend} vs last month
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Customer Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Customer Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Regular Customers</span>
                <span className="font-semibold">78%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>New Customers</span>
                <span className="font-semibold">22%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Customer Satisfaction</span>
                <span className="font-semibold text-green-600">98.5%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Repeat Purchase Rate</span>
                <span className="font-semibold">85%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payment Methods</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Cash</span>
                <span className="font-semibold">45%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>UPI/Digital</span>
                <span className="font-semibold">35%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Card</span>
                <span className="font-semibold">15%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Credit</span>
                <span className="font-semibold">5%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export function PharmacyDashboard({ user, onLogout }: PharmacyDashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'inventory':
        return <InventoryManagement user={user} />;
      case 'orders':
        return <OrderTrackingView />;
      case 'analytics':
        return <SalesAnalyticsView />;
      default:
        return (
          <div className="space-y-6">
            {/* Welcome Section */}
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-800">Welcome, {user.name}!</CardTitle>
                <p className="text-purple-600">Local Pharmacy Management Portal</p>
              </CardHeader>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Package className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                  <h3 className="text-2xl font-bold">847</h3>
                  <p className="text-sm text-gray-600">Medicines in Stock</p>
                  <p className="text-xs text-yellow-600">23 low stock alerts</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Users className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                  <h3 className="text-2xl font-bold">156</h3>
                  <p className="text-sm text-gray-600">Daily Customers</p>
                  <p className="text-xs text-green-600">+12% from yesterday</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <TrendingUp className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                  <h3 className="text-2xl font-bold">₹45,678</h3>
                  <p className="text-sm text-gray-600">Today's Sales</p>
                  <p className="text-xs text-green-600">Above target</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Pill className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                  <h3 className="text-2xl font-bold">89</h3>
                  <p className="text-sm text-gray-600">Prescriptions Filled</p>
                  <p className="text-xs text-blue-600">Today</p>
                </CardContent>
              </Card>
            </div>

            {/* Low Stock Alerts */}
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center">
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Critical Stock Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-red-100 rounded-lg">
                    <div>
                      <p className="font-medium text-red-800">Paracetamol 500mg</p>
                      <p className="text-sm text-red-600">Only 12 tablets remaining - High demand medicine</p>
                    </div>
                    <Badge className="bg-red-600">CRITICAL</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-orange-100 rounded-lg">
                    <div>
                      <p className="font-medium text-orange-800">Crocin 650mg</p>
                      <p className="text-sm text-orange-600">23 tablets left - Reorder recommended</p>
                    </div>
                    <Badge className="bg-orange-600">LOW</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-yellow-100 rounded-lg">
                    <div>
                      <p className="font-medium text-yellow-800">ORS Packets</p>
                      <p className="text-sm text-yellow-600">45 packets remaining - Monitor closely</p>
                    </div>
                    <Badge className="bg-yellow-600">MEDIUM</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Orders */}
            <Card>
              <CardHeader>
                <CardTitle className="text-purple-800">Recent Customer Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Order #1247 - Rajesh Kumar</p>
                      <p className="text-sm text-gray-600">Paracetamol, Cough Syrup, Vitamin D - ₹245</p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-600 mb-1">Completed</Badge>
                      <p className="text-xs text-gray-500">2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Order #1248 - Sunita Devi</p>
                      <p className="text-sm text-gray-600">Iron tablets, Folic acid - ₹89</p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-yellow-600 mb-1">Preparing</Badge>
                      <p className="text-xs text-gray-500">1 hour ago</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Order #1249 - Mohan Singh</p>
                      <p className="text-sm text-gray-600">Diabetes medication, BP tablets - ₹567</p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-blue-600 mb-1">Reserved</Badge>
                      <p className="text-xs text-gray-500">30 min ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('inventory')}>
                <CardHeader className="text-center">
                  <Package className="w-8 h-8 mx-auto text-purple-600" />
                  <CardTitle className="text-lg">Inventory Management</CardTitle>
                  <p className="text-sm text-gray-600">Update stock levels</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('orders')}>
                <CardHeader className="text-center">
                  <Pill className="w-8 h-8 mx-auto text-purple-600" />
                  <CardTitle className="text-lg">Order Tracking</CardTitle>
                  <p className="text-sm text-gray-600">Manage prescriptions</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('analytics')}>
                <CardHeader className="text-center">
                  <TrendingUp className="w-8 h-8 mx-auto text-purple-600" />
                  <CardTitle className="text-lg">Sales Analytics</CardTitle>
                  <p className="text-sm text-gray-600">View reports & trends</p>
                </CardHeader>
              </Card>
            </div>

            {/* Popular Medicines */}
            <Card>
              <CardHeader>
                <CardTitle className="text-purple-800">Most Requested Medicines</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">This Week's Top Sellers</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>1. Paracetamol 500mg</span>
                        <span className="font-medium">234 units</span>
                      </div>
                      <div className="flex justify-between">
                        <span>2. Crocin 650mg</span>
                        <span className="font-medium">189 units</span>
                      </div>
                      <div className="flex justify-between">
                        <span>3. ORS Packets</span>
                        <span className="font-medium">156 units</span>
                      </div>
                      <div className="flex justify-between">
                        <span>4. Vitamin D tablets</span>
                        <span className="font-medium">134 units</span>
                      </div>
                      <div className="flex justify-between">
                        <span>5. Cough Syrup</span>
                        <span className="font-medium">98 units</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Seasonal Demands</h4>
                    <div className="space-y-2 text-sm text-purple-700">
                      <div className="p-2 bg-purple-50 rounded">
                        <span className="font-medium">Winter Season:</span> Cold & flu medications
                      </div>
                      <div className="p-2 bg-purple-50 rounded">
                        <span className="font-medium">Monsoon:</span> Digestive & fever medicines
                      </div>
                      <div className="p-2 bg-purple-50 rounded">
                        <span className="font-medium">Summer:</span> Hydration & heat-related medicines
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Telemedicine Integration */}
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">Telemedicine Integration</CardTitle>
              </CardHeader>
              <CardContent className="text-blue-700">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium mb-2">Real-time Prescription Updates</h4>
                    <ul className="space-y-1">
                      <li>• Receive prescriptions from telemedicine consultations</li>
                      <li>• Auto-update medicine availability status</li>
                      <li>• Send stock alerts to healthcare platform</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Patient Benefits</h4>
                    <ul className="space-y-1">
                      <li>• Check medicine availability before traveling</li>
                      <li>• Reserve medicines through the platform</li>
                      <li>• Get notified when prescriptions are ready</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Financial Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-purple-800">Financial Summary - December 2024</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <h3 className="text-xl font-bold text-purple-700">₹8,45,678</h3>
                    <p className="text-sm text-gray-600">Total Sales</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-green-700">₹2,34,567</h3>
                    <p className="text-sm text-gray-600">Net Profit</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-blue-700">2,847</h3>
                    <p className="text-sm text-gray-600">Orders Fulfilled</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-700">98.5%</h3>
                    <p className="text-sm text-gray-600">Customer Satisfaction</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-purple-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-purple-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-xl text-purple-800">Local Pharmacy Portal</h1>
              <div className="hidden md:flex space-x-4">
                <Button 
                  variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('dashboard')}
                  className={activeTab === 'dashboard' ? 'bg-purple-600 hover:bg-purple-700' : ''}
                >
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === 'inventory' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('inventory')}
                  className={activeTab === 'inventory' ? 'bg-purple-600 hover:bg-purple-700' : ''}
                >
                  Inventory
                </Button>
                <Button 
                  variant={activeTab === 'orders' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('orders')}
                  className={activeTab === 'orders' ? 'bg-purple-600 hover:bg-purple-700' : ''}
                >
                  Orders
                </Button>
                <Button 
                  variant={activeTab === 'analytics' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('analytics')}
                  className={activeTab === 'analytics' ? 'bg-purple-600 hover:bg-purple-700' : ''}
                >
                  Analytics
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">{user.name} - Pharmacy</span>
              <Button variant="outline" onClick={onLogout} className="border-purple-300 text-purple-700 hover:bg-purple-50">
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}