import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Heart, User, AlertTriangle, CheckCircle, Plus } from 'lucide-react';

interface HealthScreeningProps {
  user: any;
}

export function HealthScreening({ user }: HealthScreeningProps) {
  const [activeView, setActiveView] = useState('list');
  const [screeningData, setScreeningData] = useState({
    patientName: '',
    age: '',
    gender: '',
    village: '',
    bloodPressure: '',
    pulse: '',
    temperature: '',
    weight: '',
    height: '',
    symptoms: '',
    riskFactors: '',
    recommendations: '',
    referralNeeded: false
  });

  const [screenings] = useState([
    {
      id: 1,
      patientName: 'Rajesh Kumar',
      age: 45,
      village: 'Khera',
      date: '2024-12-19',
      riskLevel: 'high',
      findings: 'Elevated BP (160/95), complaints of headache',
      status: 'referred'
    },
    {
      id: 2,
      patientName: 'Sunita Devi',
      age: 28,
      village: 'Sangatpura',
      date: '2024-12-18',
      riskLevel: 'low',
      findings: 'Normal vitals, pregnant (6 months)',
      status: 'routine'
    },
    {
      id: 3,
      patientName: 'Mohan Singh',
      age: 62,
      village: 'Bhamola',
      date: '2024-12-17',
      riskLevel: 'medium',
      findings: 'Diabetes symptoms, frequent urination',
      status: 'follow-up'
    }
  ]);

  const handleSubmitScreening = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to the backend
    console.log('Submitting screening:', screeningData);
    alert('Health screening recorded successfully!');
    setScreeningData({
      patientName: '',
      age: '',
      gender: '',
      village: '',
      bloodPressure: '',
      pulse: '',
      temperature: '',
      weight: '',
      height: '',
      symptoms: '',
      riskFactors: '',
      recommendations: '',
      referralNeeded: false
    });
    setActiveView('list');
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'routine': return 'bg-blue-100 text-blue-800';
      case 'follow-up': return 'bg-yellow-100 text-yellow-800';
      case 'referred': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-orange-800">
                <Heart className="w-5 h-5 mr-2" />
                Health Screening & Assessment
              </CardTitle>
              <p className="text-sm text-gray-600">
                Conduct basic health checks and identify health risks in the community
              </p>
            </div>
            <Button 
              onClick={() => setActiveView('new')}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Plus className="w-4 h-4 mr-1" />
              New Screening
            </Button>
          </div>
        </CardHeader>
      </Card>

      {activeView === 'new' ? (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>New Health Screening</CardTitle>
              <Button variant="outline" onClick={() => setActiveView('list')}>
                Back to List
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitScreening} className="space-y-6">
              {/* Patient Information */}
              <div>
                <h3 className="font-medium mb-3">Patient Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="patientName">Patient Name *</Label>
                    <Input
                      id="patientName"
                      value={screeningData.patientName}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, patientName: e.target.value }))}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="age">Age *</Label>
                    <Input
                      id="age"
                      type="number"
                      value={screeningData.age}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, age: e.target.value }))}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="gender">Gender *</Label>
                    <Select value={screeningData.gender} onValueChange={(value) => setScreeningData(prev => ({ ...prev, gender: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="village">Village *</Label>
                    <Select value={screeningData.village} onValueChange={(value) => setScreeningData(prev => ({ ...prev, village: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select village" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Khera">Khera</SelectItem>
                        <SelectItem value="Sangatpura">Sangatpura</SelectItem>
                        <SelectItem value="Bhamola">Bhamola</SelectItem>
                        <SelectItem value="Rampura">Rampura</SelectItem>
                        <SelectItem value="Malaudh">Malaudh</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Vital Signs */}
              <div>
                <h3 className="font-medium mb-3">Vital Signs</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="bloodPressure">Blood Pressure</Label>
                    <Input
                      id="bloodPressure"
                      placeholder="e.g., 120/80"
                      value={screeningData.bloodPressure}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, bloodPressure: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="pulse">Pulse Rate</Label>
                    <Input
                      id="pulse"
                      placeholder="beats/min"
                      value={screeningData.pulse}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, pulse: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="temperature">Temperature</Label>
                    <Input
                      id="temperature"
                      placeholder="°F"
                      value={screeningData.temperature}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, temperature: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      value={screeningData.weight}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, weight: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              {/* Symptoms and Assessment */}
              <div>
                <h3 className="font-medium mb-3">Health Assessment</h3>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="symptoms">Current Symptoms/Complaints</Label>
                    <Textarea
                      id="symptoms"
                      value={screeningData.symptoms}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, symptoms: e.target.value }))}
                      placeholder="Describe any symptoms or health complaints..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="riskFactors">Risk Factors Identified</Label>
                    <Textarea
                      id="riskFactors"
                      value={screeningData.riskFactors}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, riskFactors: e.target.value }))}
                      placeholder="Family history, lifestyle factors, environmental risks..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="recommendations">Recommendations</Label>
                    <Textarea
                      id="recommendations"
                      value={screeningData.recommendations}
                      onChange={(e) => setScreeningData(prev => ({ ...prev, recommendations: e.target.value }))}
                      placeholder="Health advice, lifestyle changes, follow-up care..."
                    />
                  </div>
                </div>
              </div>

              {/* Referral Decision */}
              <div className="bg-yellow-50 p-4 rounded-lg">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="referralNeeded"
                    checked={screeningData.referralNeeded}
                    onChange={(e) => setScreeningData(prev => ({ ...prev, referralNeeded: e.target.checked }))}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="referralNeeded" className="font-medium">
                    Referral to Civil Hospital Required
                  </Label>
                </div>
                {screeningData.referralNeeded && (
                  <p className="text-sm text-yellow-700 mt-2">
                    Patient will be referred to Nabha Civil Hospital for further evaluation and treatment.
                  </p>
                )}
              </div>

              <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700">
                Complete Screening
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Screening List */}
          <div className="space-y-4">
            {screenings.map((screening) => (
              <Card key={screening.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <User className="w-5 h-5 text-gray-500" />
                        <h3 className="text-lg font-medium">{screening.patientName}</h3>
                        <Badge className={getRiskColor(screening.riskLevel)}>
                          {screening.riskLevel} risk
                        </Badge>
                        <Badge className={getStatusColor(screening.status)}>
                          {screening.status}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3 text-sm text-gray-600">
                        <span>Age: {screening.age} years</span>
                        <span>Village: {screening.village}</span>
                        <span>Date: {new Date(screening.date).toLocaleDateString('en-IN')}</span>
                      </div>

                      <p className="text-gray-600">{screening.findings}</p>
                    </div>

                    <div className="ml-4">
                      {screening.riskLevel === 'high' && (
                        <AlertTriangle className="w-6 h-6 text-red-500" />
                      )}
                      {screening.riskLevel === 'low' && (
                        <CheckCircle className="w-6 h-6 text-green-500" />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Reference Guide */}
          <Card className="bg-orange-50 border-orange-200">
            <CardHeader>
              <CardTitle className="text-orange-800">Quick Reference - Normal Ranges</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                <div>
                  <h4 className="font-medium mb-2">Vital Signs (Adults)</h4>
                  <ul className="space-y-1 text-orange-700">
                    <li>• Blood Pressure: 90/60 - 140/90 mmHg</li>
                    <li>• Pulse Rate: 60-100 beats/min</li>
                    <li>• Temperature: 97-99°F (36-37°C)</li>
                    <li>• BMI: 18.5-24.9 kg/m²</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Warning Signs (Refer Immediately)</h4>
                  <ul className="space-y-1 text-red-700">
                    <li>• BP {`>`} 140/90 or {`<`} 90/60</li>
                    <li>• Fever {`>`} 101°F (38.3°C)</li>
                    <li>• Chest pain or difficulty breathing</li>
                    <li>• Severe abdominal pain</li>
                    <li>• Signs of dehydration</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Summary Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-orange-800">Screening Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <h3 className="text-2xl font-bold text-green-700">
                    {screenings.filter(s => s.riskLevel === 'low').length}
                  </h3>
                  <p className="text-sm text-green-600">Low Risk</p>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-yellow-700">
                    {screenings.filter(s => s.riskLevel === 'medium').length}
                  </h3>
                  <p className="text-sm text-yellow-600">Medium Risk</p>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-red-700">
                    {screenings.filter(s => s.riskLevel === 'high').length}
                  </h3>
                  <p className="text-sm text-red-600">High Risk</p>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-purple-700">
                    {screenings.filter(s => s.status === 'referred').length}
                  </h3>
                  <p className="text-sm text-purple-600">Referred</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}