import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Heart, Users, MapPin, Phone, FileText, TrendingUp, LogOut } from 'lucide-react';
import { CommunityOutreach } from './CommunityOutreach';
import { HealthScreening } from './HealthScreening';
import { VillageReports } from './VillageReports';

interface ASHADashboardProps {
  user: any;
  onLogout: () => void;
}

export function ASHADashboard({ user, onLogout }: ASHADashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'outreach':
        return <CommunityOutreach user={user} />;
      case 'screening':
        return <HealthScreening user={user} />;
      case 'reports':
        return <VillageReports user={user} />;
      default:
        return (
          <div className="space-y-6">
            {/* Welcome Section */}
            <Card className="bg-orange-50 border-orange-200">
              <CardHeader>
                <CardTitle className="text-orange-800">नमस्ते, {user.name}!</CardTitle>
                <p className="text-orange-600">ASHA Worker Community Health Dashboard</p>
              </CardHeader>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Users className="w-8 h-8 mx-auto text-orange-600 mb-2" />
                  <h3 className="text-2xl font-bold">847</h3>
                  <p className="text-sm text-gray-600">Families Served</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Heart className="w-8 h-8 mx-auto text-orange-600 mb-2" />
                  <h3 className="text-2xl font-bold">23</h3>
                  <p className="text-sm text-gray-600">Health Screenings</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <MapPin className="w-8 h-8 mx-auto text-orange-600 mb-2" />
                  <h3 className="text-2xl font-bold">12</h3>
                  <p className="text-sm text-gray-600">Villages Covered</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Phone className="w-8 h-8 mx-auto text-orange-600 mb-2" />
                  <h3 className="text-2xl font-bold">156</h3>
                  <p className="text-sm text-gray-600">Referrals Made</p>
                </CardContent>
              </Card>
            </div>

            {/* Today's Tasks */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-orange-800">
                  <FileText className="w-5 h-5 mr-2" />
                  Today's Priority Tasks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-orange-50 border border-orange-200 rounded-lg">
                    <div>
                      <p className="font-medium">Maternal Health Check - Village Khera</p>
                      <p className="text-sm text-gray-600">3 pregnant women due for checkup</p>
                    </div>
                    <Badge className="bg-orange-600">High Priority</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Child Immunization Drive - Village Sangatpura</p>
                      <p className="text-sm text-gray-600">15 children scheduled for vaccination</p>
                    </div>
                    <Badge variant="secondary">Scheduled</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Hypertension Screening - Village Bhamola</p>
                      <p className="text-sm text-gray-600">Adults above 40 years</p>
                    </div>
                    <Badge variant="outline">Pending</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('outreach')}>
                <CardHeader className="text-center">
                  <Users className="w-8 h-8 mx-auto text-orange-600" />
                  <CardTitle className="text-lg">Community Outreach</CardTitle>
                  <p className="text-sm text-gray-600">Village health programs</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('screening')}>
                <CardHeader className="text-center">
                  <Heart className="w-8 h-8 mx-auto text-orange-600" />
                  <CardTitle className="text-lg">Health Screening</CardTitle>
                  <p className="text-sm text-gray-600">Basic health checks</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('reports')}>
                <CardHeader className="text-center">
                  <TrendingUp className="w-8 h-8 mx-auto text-orange-600" />
                  <CardTitle className="text-lg">Village Reports</CardTitle>
                  <p className="text-sm text-gray-600">Health data & analytics</p>
                </CardHeader>
              </Card>
            </div>

            {/* Health Alerts */}
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800">Health Alerts & Warnings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center p-2 bg-red-100 rounded">
                    <div className="w-3 h-3 bg-red-500 rounded-full mr-3"></div>
                    <p className="text-red-700">Dengue cases reported in nearby district - Increase vector control measures</p>
                  </div>
                  <div className="flex items-center p-2 bg-yellow-100 rounded">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                    <p className="text-yellow-700">Monsoon season - Focus on water-borne disease prevention</p>
                  </div>
                  <div className="flex items-center p-2 bg-blue-100 rounded">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                    <p className="text-blue-700">Vaccination drive next week - Prepare beneficiary lists</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activities */}
            <Card>
              <CardHeader>
                <CardTitle className="text-orange-800">Recent Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between items-center">
                    <span>Conducted health screening in Village Khera</span>
                    <span className="text-gray-500">2 hours ago</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Referred pregnant woman to Civil Hospital</span>
                    <span className="text-gray-500">4 hours ago</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Completed immunization drive</span>
                    <span className="text-gray-500">Yesterday</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Submitted monthly village report</span>
                    <span className="text-gray-500">2 days ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-orange-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-xl text-orange-800">ASHA Worker Portal</h1>
              <div className="hidden md:flex space-x-4">
                <Button 
                  variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('dashboard')}
                  className={activeTab === 'dashboard' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                >
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === 'outreach' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('outreach')}
                  className={activeTab === 'outreach' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                >
                  Community Outreach
                </Button>
                <Button 
                  variant={activeTab === 'screening' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('screening')}
                  className={activeTab === 'screening' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                >
                  Health Screening
                </Button>
                <Button 
                  variant={activeTab === 'reports' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('reports')}
                  className={activeTab === 'reports' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                >
                  Village Reports
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">ASHA {user.name}</span>
              <Button variant="outline" onClick={onLogout} className="border-orange-300 text-orange-700 hover:bg-orange-50">
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}