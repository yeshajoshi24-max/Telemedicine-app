import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, FileText, Download, Calendar } from 'lucide-react';

interface VillageReportsProps {
  user: any;
}

export function VillageReports({ user }: VillageReportsProps) {
  const [selectedVillage, setSelectedVillage] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  // Sample data for charts
  const healthMetrics = [
    { month: 'Aug', screenings: 45, referrals: 8, programs: 3 },
    { month: 'Sep', screenings: 52, referrals: 12, programs: 4 },
    { month: 'Oct', screenings: 38, referrals: 6, programs: 2 },
    { month: 'Nov', screenings: 41, referrals: 9, programs: 5 },
    { month: 'Dec', screenings: 23, referrals: 4, programs: 2 }
  ];

  const diseaseDistribution = [
    { name: 'Hypertension', value: 35, color: '#8884d8' },
    { name: 'Diabetes', value: 28, color: '#82ca9d' },
    { name: 'Respiratory', value: 20, color: '#ffc658' },
    { name: 'Malnutrition', value: 12, color: '#ff7300' },
    { name: 'Others', value: 5, color: '#8dd1e1' }
  ];

  const villageData = {
    Khera: {
      population: 1247,
      households: 312,
      childrenUnder5: 89,
      pregnantWomen: 23,
      elderlyAbove60: 156,
      lastScreening: '2024-12-18'
    },
    Sangatpura: {
      population: 892,
      households: 234,
      childrenUnder5: 67,
      pregnantWomen: 18,
      elderlyAbove60: 98,
      lastScreening: '2024-12-17'
    },
    Bhamola: {
      population: 1456,
      households: 398,
      childrenUnder5: 102,
      pregnantWomen: 31,
      elderlyAbove60: 189,
      lastScreening: '2024-12-19'
    }
  };

  const generateReport = () => {
    // In a real app, this would generate a PDF report
    alert('Generating comprehensive health report for ' + (selectedVillage === 'all' ? 'all villages' : selectedVillage));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-orange-800">
                <TrendingUp className="w-5 h-5 mr-2" />
                Village Health Reports & Analytics
              </CardTitle>
              <p className="text-sm text-gray-600">
                Monitor health trends and generate reports for better community health planning
              </p>
            </div>
            <Button onClick={generateReport} className="bg-orange-600 hover:bg-orange-700">
              <Download className="w-4 h-4 mr-1" />
              Generate Report
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Village</label>
              <Select value={selectedVillage} onValueChange={setSelectedVillage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Villages</SelectItem>
                  <SelectItem value="Khera">Khera</SelectItem>
                  <SelectItem value="Sangatpura">Sangatpura</SelectItem>
                  <SelectItem value="Bhamola">Bhamola</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Time Period</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Last Week</SelectItem>
                  <SelectItem value="month">Last Month</SelectItem>
                  <SelectItem value="quarter">Last Quarter</SelectItem>
                  <SelectItem value="year">Last Year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button variant="outline" className="w-full border-orange-300">
                <Calendar className="w-4 h-4 mr-1" />
                Custom Date Range
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <h3 className="text-2xl font-bold text-orange-600">159</h3>
            <p className="text-sm text-gray-600">Total Screenings</p>
            <p className="text-xs text-green-600">+12% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <h3 className="text-2xl font-bold text-red-600">39</h3>
            <p className="text-sm text-gray-600">Hospital Referrals</p>
            <p className="text-xs text-yellow-600">+5% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <h3 className="text-2xl font-bold text-green-600">16</h3>
            <p className="text-sm text-gray-600">Health Programs</p>
            <p className="text-xs text-green-600">+3 from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <h3 className="text-2xl font-bold text-blue-600">2,841</h3>
            <p className="text-sm text-gray-600">People Reached</p>
            <p className="text-xs text-green-600">+8% coverage</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Health Activity Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Health Activity Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={healthMetrics}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="screenings" fill="#f97316" name="Screenings" />
                <Bar dataKey="referrals" fill="#ef4444" name="Referrals" />
                <Bar dataKey="programs" fill="#22c55e" name="Programs" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Disease Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Common Health Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={diseaseDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {diseaseDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Village Demographics */}
      <Card>
        <CardHeader>
          <CardTitle>Village Demographics Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(villageData).map(([village, data]) => (
              <div key={village} className="p-4 border border-orange-200 rounded-lg">
                <h3 className="font-medium text-orange-800 mb-3">{village}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Total Population:</span>
                    <span className="font-medium">{data.population}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Households:</span>
                    <span className="font-medium">{data.households}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Children Under 5:</span>
                    <span className="font-medium">{data.childrenUnder5}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pregnant Women:</span>
                    <span className="font-medium">{data.pregnantWomen}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Elderly (60+):</span>
                    <span className="font-medium">{data.elderlyAbove60}</span>
                  </div>
                  <div className="pt-2 border-t">
                    <div className="flex justify-between">
                      <span>Last Screening:</span>
                      <span className="text-xs">{new Date(data.lastScreening).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Monthly Report Summary */}
      <Card className="bg-orange-50 border-orange-200">
        <CardHeader>
          <CardTitle className="text-orange-800">December 2024 Monthly Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Key Achievements</h4>
              <ul className="space-y-2 text-sm text-orange-700">
                <li>• Conducted health screenings for 159 community members</li>
                <li>• Organized 5 health awareness programs</li>
                <li>• Successfully referred 39 high-risk cases to hospital</li>
                <li>• Completed immunization drive covering 120 children</li>
                <li>• Distributed iron tablets to 45 pregnant women</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Areas for Improvement</h4>
              <ul className="space-y-2 text-sm text-orange-700">
                <li>• Increase diabetes screening in elderly population</li>
                <li>• Enhance maternal nutrition counseling</li>
                <li>• Improve follow-up rate for referred patients</li>
                <li>• Expand family planning awareness programs</li>
                <li>• Address seasonal disease prevention</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Items */}
      <Card>
        <CardHeader>
          <CardTitle className="text-orange-800">Upcoming Action Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div>
                <p className="font-medium">Quarterly Health Camp Planning</p>
                <p className="text-sm text-gray-600">Coordinate with hospital for specialist consultation camp</p>
              </div>
              <Badge className="bg-yellow-600">Due: Dec 25</Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div>
                <p className="font-medium">Annual Health Survey</p>
                <p className="text-sm text-gray-600">Complete comprehensive health assessment for all villages</p>
              </div>
              <Badge className="bg-blue-600">Due: Jan 15</Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
              <div>
                <p className="font-medium">Health Education Material Update</p>
                <p className="text-sm text-gray-600">Prepare seasonal health awareness materials</p>
              </div>
              <Badge className="bg-green-600">Due: Jan 5</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}