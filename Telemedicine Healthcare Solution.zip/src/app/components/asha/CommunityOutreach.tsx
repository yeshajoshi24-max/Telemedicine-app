import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Users, MapPin, Calendar, Plus, CheckCircle } from 'lucide-react';

interface CommunityOutreachProps {
  user: any;
}

export function CommunityOutreach({ user }: CommunityOutreachProps) {
  const [activeView, setActiveView] = useState('programs');
  const [newProgram, setNewProgram] = useState({
    title: '',
    village: '',
    date: '',
    type: '',
    description: '',
    targetBeneficiaries: ''
  });

  const [programs] = useState([
    {
      id: 1,
      title: 'Maternal Health Awareness',
      village: 'Khera',
      date: '2024-12-20',
      type: 'health_education',
      status: 'scheduled',
      beneficiaries: 25,
      description: 'Antenatal care and nutrition awareness session'
    },
    {
      id: 2,
      title: 'Child Immunization Drive',
      village: 'Sangatpura',
      date: '2024-12-22',
      type: 'immunization',
      status: 'scheduled',
      beneficiaries: 40,
      description: 'Routine immunization for children 0-5 years'
    },
    {
      id: 3,
      title: 'Hygiene and Sanitation Workshop',
      village: 'Bhamola',
      date: '2024-12-18',
      type: 'health_education',
      status: 'completed',
      beneficiaries: 60,
      description: 'Hand washing and clean water practices'
    }
  ]);

  const handleCreateProgram = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to the backend
    console.log('Creating program:', newProgram);
    alert('Program scheduled successfully!');
    setNewProgram({
      title: '',
      village: '',
      date: '',
      type: '',
      description: '',
      targetBeneficiaries: ''
    });
    setActiveView('programs');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'immunization': return 'bg-purple-100 text-purple-800';
      case 'health_education': return 'bg-orange-100 text-orange-800';
      case 'screening': return 'bg-green-100 text-green-800';
      case 'nutrition': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-orange-800">
                <Users className="w-5 h-5 mr-2" />
                Community Outreach Programs
              </CardTitle>
              <p className="text-sm text-gray-600">
                Plan and manage village health programs and awareness campaigns
              </p>
            </div>
            <Button 
              onClick={() => setActiveView('create')}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Plus className="w-4 h-4 mr-1" />
              New Program
            </Button>
          </div>
        </CardHeader>
      </Card>

      {activeView === 'create' ? (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Schedule New Outreach Program</CardTitle>
              <Button variant="outline" onClick={() => setActiveView('programs')}>
                Back to Programs
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateProgram} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Program Title *</Label>
                  <Input
                    id="title"
                    value={newProgram.title}
                    onChange={(e) => setNewProgram(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Maternal Health Awareness"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="village">Village *</Label>
                  <Select value={newProgram.village} onValueChange={(value) => setNewProgram(prev => ({ ...prev, village: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select village" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Khera">Khera</SelectItem>
                      <SelectItem value="Sangatpura">Sangatpura</SelectItem>
                      <SelectItem value="Bhamola">Bhamola</SelectItem>
                      <SelectItem value="Rampura">Rampura</SelectItem>
                      <SelectItem value="Malaudh">Malaudh</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="date">Date *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newProgram.date}
                    onChange={(e) => setNewProgram(prev => ({ ...prev, date: e.target.value }))}
                    min={new Date().toISOString().split('T')[0]}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="type">Program Type *</Label>
                  <Select value={newProgram.type} onValueChange={(value) => setNewProgram(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="health_education">Health Education</SelectItem>
                      <SelectItem value="immunization">Immunization Drive</SelectItem>
                      <SelectItem value="screening">Health Screening</SelectItem>
                      <SelectItem value="nutrition">Nutrition Program</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="beneficiaries">Target Beneficiaries</Label>
                  <Input
                    id="beneficiaries"
                    type="number"
                    value={newProgram.targetBeneficiaries}
                    onChange={(e) => setNewProgram(prev => ({ ...prev, targetBeneficiaries: e.target.value }))}
                    placeholder="Expected number of participants"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Program Description *</Label>
                <Textarea
                  id="description"
                  value={newProgram.description}
                  onChange={(e) => setNewProgram(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe the program objectives, activities, and target audience..."
                  className="min-h-[100px]"
                  required
                />
              </div>

              <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700">
                Schedule Program
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Programs List */}
          <div className="space-y-4">
            {programs.map((program) => (
              <Card key={program.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-medium">{program.title}</h3>
                        <Badge className={getStatusColor(program.status)}>
                          {program.status}
                        </Badge>
                        <Badge className={getTypeColor(program.type)}>
                          {program.type.replace('_', ' ')}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3 text-sm text-gray-600">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          <span>Village {program.village}</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          <span>{new Date(program.date).toLocaleDateString('en-IN')}</span>
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          <span>{program.beneficiaries} beneficiaries</span>
                        </div>
                      </div>

                      <p className="text-gray-600 mb-3">{program.description}</p>
                    </div>

                    <div className="ml-4">
                      {program.status === 'scheduled' && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Mark Complete
                        </Button>
                      )}
                      {program.status === 'completed' && (
                        <Badge variant="secondary">
                          Completed
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Stats */}
          <Card className="bg-orange-50 border-orange-200">
            <CardHeader>
              <CardTitle className="text-orange-800">Outreach Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <h3 className="text-2xl font-bold text-orange-700">
                    {programs.filter(p => p.status === 'scheduled').length}
                  </h3>
                  <p className="text-sm text-orange-600">Scheduled</p>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-green-700">
                    {programs.filter(p => p.status === 'completed').length}
                  </h3>
                  <p className="text-sm text-green-600">Completed</p>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-blue-700">
                    {programs.reduce((sum, p) => sum + p.beneficiaries, 0)}
                  </h3>
                  <p className="text-sm text-blue-600">Total Beneficiaries</p>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-purple-700">
                    {new Set(programs.map(p => p.village)).size}
                  </h3>
                  <p className="text-sm text-purple-600">Villages Covered</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Program Templates */}
          <Card>
            <CardHeader>
              <CardTitle className="text-orange-800">Program Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border border-orange-200 rounded-lg">
                  <h4 className="font-medium mb-2">Maternal Health Package</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Comprehensive antenatal care, nutrition counseling, and delivery preparation
                  </p>
                  <Button size="sm" variant="outline" className="border-orange-300">
                    Use Template
                  </Button>
                </div>

                <div className="p-4 border border-orange-200 rounded-lg">
                  <h4 className="font-medium mb-2">Child Health & Nutrition</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Growth monitoring, immunization tracking, and nutritional assessment
                  </p>
                  <Button size="sm" variant="outline" className="border-orange-300">
                    Use Template
                  </Button>
                </div>

                <div className="p-4 border border-orange-200 rounded-lg">
                  <h4 className="font-medium mb-2">Family Planning</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Contraceptive counseling and reproductive health education
                  </p>
                  <Button size="sm" variant="outline" className="border-orange-300">
                    Use Template
                  </Button>
                </div>

                <div className="p-4 border border-orange-200 rounded-lg">
                  <h4 className="font-medium mb-2">Elderly Care</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Chronic disease management and mobility support
                  </p>
                  <Button size="sm" variant="outline" className="border-orange-300">
                    Use Template
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}