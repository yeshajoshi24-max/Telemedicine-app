import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Calendar, Clock, Users, Video, FileText, Settings, LogOut } from 'lucide-react';
import { DoctorSchedule } from './DoctorSchedule';
import { PatientAppointments } from './PatientAppointments';
import { HealthRecordForm } from './HealthRecordForm';

interface HospitalDashboardProps {
  user: any;
  onLogout: () => void;
}

export function HospitalDashboard({ user, onLogout }: HospitalDashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [todayAppointments, setTodayAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTodayAppointments();
  }, []);

  const fetchTodayAppointments = async () => {
    try {
      const { projectId } = await import('../../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f2ba4e71/appointments/doctor`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
        },
      });
      const data = await response.json();
      
      // Filter for today's appointments
      const today = new Date().toISOString().split('T')[0];
      const todayAppts = (data.appointments || []).filter(apt => apt.date === today);
      setTodayAppointments(todayAppts);
    } catch (error) {
      console.error('Failed to fetch appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'schedule':
        return <DoctorSchedule user={user} />;
      case 'appointments':
        return <PatientAppointments user={user} />;
      case 'records':
        return <HealthRecordForm user={user} />;
      default:
        return (
          <div className="space-y-6">
            {/* Welcome Section */}
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800">Welcome, Dr. {user.name}!</CardTitle>
                <p className="text-red-600">Nabha Civil Hospital Staff Portal</p>
              </CardHeader>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Users className="w-8 h-8 mx-auto text-red-600 mb-2" />
                  <h3 className="text-2xl font-bold">{todayAppointments.length}</h3>
                  <p className="text-sm text-gray-600">Today's Patients</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Calendar className="w-8 h-8 mx-auto text-red-600 mb-2" />
                  <h3 className="text-2xl font-bold">173</h3>
                  <p className="text-sm text-gray-600">Villages Served</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <FileText className="w-8 h-8 mx-auto text-red-600 mb-2" />
                  <h3 className="text-2xl font-bold">11</h3>
                  <p className="text-sm text-gray-600">Active Doctors</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <Video className="w-8 h-8 mx-auto text-red-600 mb-2" />
                  <h3 className="text-2xl font-bold">24/7</h3>
                  <p className="text-sm text-gray-600">Telemedicine</p>
                </CardContent>
              </Card>
            </div>

            {/* Today's Schedule */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-red-800">
                  <Clock className="w-5 h-5 mr-2" />
                  Today's Appointments
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <p>Loading appointments...</p>
                ) : todayAppointments.length === 0 ? (
                  <p className="text-gray-600">No appointments scheduled for today.</p>
                ) : (
                  <div className="space-y-3">
                    {todayAppointments.map((apt, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium">Patient ID: {apt.patientId}</p>
                          <p className="text-sm text-gray-600">{apt.time} - {apt.symptoms}</p>
                          <Badge variant={apt.urgency === 'high' ? 'destructive' : apt.urgency === 'normal' ? 'default' : 'secondary'}>
                            {apt.urgency} priority
                          </Badge>
                        </div>
                        <div className="text-right">
                          <Button size="sm" className="bg-red-600 hover:bg-red-700 mb-1">
                            <Video className="w-4 h-4 mr-1" />
                            Start Consultation
                          </Button>
                          <p className="text-xs text-gray-500">Status: {apt.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('schedule')}>
                <CardHeader className="text-center">
                  <Settings className="w-8 h-8 mx-auto text-red-600" />
                  <CardTitle className="text-lg">Manage Schedule</CardTitle>
                  <p className="text-sm text-gray-600">Set availability times</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('appointments')}>
                <CardHeader className="text-center">
                  <Users className="w-8 h-8 mx-auto text-red-600" />
                  <CardTitle className="text-lg">View All Patients</CardTitle>
                  <p className="text-sm text-gray-600">Manage appointments</p>
                </CardHeader>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('records')}>
                <CardHeader className="text-center">
                  <FileText className="w-8 h-8 mx-auto text-red-600" />
                  <CardTitle className="text-lg">Add Health Record</CardTitle>
                  <p className="text-sm text-gray-600">Create patient records</p>
                </CardHeader>
              </Card>
            </div>

            {/* Hospital Information */}
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">Nabha Civil Hospital</CardTitle>
              </CardHeader>
              <CardContent className="text-blue-700">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>Sanctioned Doctors:</strong> 23</p>
                    <p><strong>Current Staff:</strong> 11 (48% capacity)</p>
                    <p><strong>Villages Served:</strong> 173</p>
                  </div>
                  <div>
                    <p><strong>Emergency Contact:</strong> 108</p>
                    <p><strong>Hospital Phone:</strong> +91-1765-XXXXX</p>
                    <p><strong>Operating Hours:</strong> 24/7</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-red-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-xl text-red-800">Civil Hospital Staff Portal</h1>
              <div className="hidden md:flex space-x-4">
                <Button 
                  variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('dashboard')}
                  className={activeTab === 'dashboard' ? 'bg-red-600 hover:bg-red-700' : ''}
                >
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === 'schedule' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('schedule')}
                  className={activeTab === 'schedule' ? 'bg-red-600 hover:bg-red-700' : ''}
                >
                  My Schedule
                </Button>
                <Button 
                  variant={activeTab === 'appointments' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('appointments')}
                  className={activeTab === 'appointments' ? 'bg-red-600 hover:bg-red-700' : ''}
                >
                  Patient Appointments
                </Button>
                <Button 
                  variant={activeTab === 'records' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('records')}
                  className={activeTab === 'records' ? 'bg-red-600 hover:bg-red-700' : ''}
                >
                  Health Records
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Dr. {user.name}</span>
              <Button variant="outline" onClick={onLogout} className="border-red-300 text-red-700 hover:bg-red-50">
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}