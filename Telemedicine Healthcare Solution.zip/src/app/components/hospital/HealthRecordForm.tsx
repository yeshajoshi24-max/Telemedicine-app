import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { FileText, Save, Search } from 'lucide-react';

interface HealthRecordFormProps {
  user: any;
}

export function HealthRecordForm({ user }: HealthRecordFormProps) {
  const [patientId, setPatientId] = useState('');
  const [formData, setFormData] = useState({
    diagnosis: '',
    prescription: '',
    notes: '',
    followUpDate: '',
    severity: 'normal'
  });
  const [loading, setLoading] = useState(false);
  const [searchMode, setSearchMode] = useState(true);

  const handlePatientSearch = () => {
    if (!patientId.trim()) {
      alert('Please enter a patient ID');
      return;
    }
    // In a real app, this would search for the patient
    setSearchMode(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientId || !formData.diagnosis || !formData.prescription) {
      alert('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      const { projectId } = await import('../../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f2ba4e71/health-records`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify({
          patientId,
          ...formData
        }),
      });

      const result = await response.json();
      if (result.success) {
        alert('Health record created successfully!');
        // Reset form
        setPatientId('');
        setFormData({
          diagnosis: '',
          prescription: '',
          notes: '',
          followUpDate: '',
          severity: 'normal'
        });
        setSearchMode(true);
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Failed to create health record:', error);
      alert('Failed to create health record. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setSearchMode(true);
    setPatientId('');
    setFormData({
      diagnosis: '',
      prescription: '',
      notes: '',
      followUpDate: '',
      severity: 'normal'
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-red-800">
            <FileText className="w-5 h-5 mr-2" />
            Create Health Record
          </CardTitle>
          <p className="text-sm text-gray-600">
            Document patient consultation and create digital health records
          </p>
        </CardHeader>
      </Card>

      {/* Patient Search */}
      {searchMode ? (
        <Card>
          <CardHeader>
            <CardTitle>Find Patient</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-2">
              <div className="flex-1">
                <Label htmlFor="patientSearch">Patient ID</Label>
                <Input
                  id="patientSearch"
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  placeholder="Enter patient ID (e.g., from appointment)"
                />
              </div>
              <div className="flex items-end">
                <Button onClick={handlePatientSearch} className="bg-red-600 hover:bg-red-700">
                  <Search className="w-4 h-4 mr-1" />
                  Find Patient
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        /* Health Record Form */
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Health Record for Patient: {patientId}</CardTitle>
                <p className="text-sm text-gray-600">Complete the consultation record</p>
              </div>
              <Button variant="outline" onClick={resetForm}>
                Change Patient
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Diagnosis */}
              <div>
                <Label htmlFor="diagnosis">Diagnosis *</Label>
                <Textarea
                  id="diagnosis"
                  value={formData.diagnosis}
                  onChange={(e) => setFormData(prev => ({ ...prev, diagnosis: e.target.value }))}
                  placeholder="Enter the primary diagnosis and any secondary conditions..."
                  className="min-h-[100px]"
                  required
                />
              </div>

              {/* Prescription */}
              <div>
                <Label htmlFor="prescription">Prescription *</Label>
                <Textarea
                  id="prescription"
                  value={formData.prescription}
                  onChange={(e) => setFormData(prev => ({ ...prev, prescription: e.target.value }))}
                  placeholder="List medications, dosages, and instructions..."
                  className="min-h-[120px]"
                  required
                />
              </div>

              {/* Additional Notes */}
              <div>
                <Label htmlFor="notes">Additional Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="Any additional observations, recommendations, or instructions..."
                  className="min-h-[80px]"
                />
              </div>

              {/* Severity and Follow-up */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Condition Severity</Label>
                  <Select value={formData.severity} onValueChange={(value) => setFormData(prev => ({ ...prev, severity: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mild">Mild - Minor condition</SelectItem>
                      <SelectItem value="normal">Normal - Regular treatment</SelectItem>
                      <SelectItem value="serious">Serious - Close monitoring needed</SelectItem>
                      <SelectItem value="critical">Critical - Immediate attention required</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="followUp">Follow-up Date (if needed)</Label>
                  <Input
                    id="followUp"
                    type="date"
                    value={formData.followUpDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, followUpDate: e.target.value }))}
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
              </div>

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full bg-red-600 hover:bg-red-700"
                disabled={loading}
              >
                <Save className="w-4 h-4 mr-2" />
                {loading ? 'Saving Record...' : 'Save Health Record'}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Quick Templates */}
      {!searchMode && (
        <Card className="bg-red-50 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800">Quick Templates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button
                variant="outline"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  diagnosis: 'Viral Fever',
                  prescription: 'Paracetamol 500mg - 1 tablet every 6 hours for 3 days\nRest and increased fluid intake\nIsolation for 3-5 days'
                }))}
                className="text-left p-4 h-auto flex flex-col items-start"
              >
                <strong>Viral Fever</strong>
                <span className="text-sm text-gray-600 mt-1">Common cold/flu symptoms</span>
              </Button>

              <Button
                variant="outline"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  diagnosis: 'Gastroenteritis',
                  prescription: 'ORS - 1 packet in 1 liter water, sip frequently\nZinc tablets - 1 daily for 10 days\nLight diet (rice, curd, banana)\nAvoid dairy and spicy foods'
                }))}
                className="text-left p-4 h-auto flex flex-col items-start"
              >
                <strong>Gastroenteritis</strong>
                <span className="text-sm text-gray-600 mt-1">Stomach infection</span>
              </Button>

              <Button
                variant="outline"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  diagnosis: 'Upper Respiratory Tract Infection',
                  prescription: 'Azithromycin 500mg - 1 tablet daily for 3 days\nCough syrup - 2 tsp three times daily\nSteam inhalation twice daily\nWarm salt water gargling'
                }))}
                className="text-left p-4 h-auto flex flex-col items-start"
              >
                <strong>Upper Respiratory Infection</strong>
                <span className="text-sm text-gray-600 mt-1">Throat and chest congestion</span>
              </Button>

              <Button
                variant="outline"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  diagnosis: 'Hypertension - Routine Check',
                  prescription: 'Continue current medication\nReduce salt intake\nRegular exercise - 30 minutes daily\nMonitor BP weekly'
                }))}
                className="text-left p-4 h-auto flex flex-col items-start"
              >
                <strong>Hypertension Follow-up</strong>
                <span className="text-sm text-gray-600 mt-1">Blood pressure management</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Record Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle className="text-gray-800">Record Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-gray-600">
            <li>• Include specific medication names, dosages, and duration</li>
            <li>• Document any allergies or contraindications</li>
            <li>• Provide clear follow-up instructions</li>
            <li>• Note any referrals to specialists if needed</li>
            <li>• Include lifestyle recommendations (diet, exercise, rest)</li>
            <li>• Records are automatically shared with patients</li>
            <li>• All records are encrypted and HIPAA compliant</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}