import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Switch } from '../ui/switch';
import { Calendar, Clock, Plus, Trash2 } from 'lucide-react';

interface DoctorScheduleProps {
  user: any;
}

export function DoctorSchedule({ user }: DoctorScheduleProps) {
  const [selectedDate, setSelectedDate] = useState('');
  const [timeSlots, setTimeSlots] = useState(['09:00', '10:00', '11:00', '14:00', '15:00', '16:00']);
  const [newTimeSlot, setNewTimeSlot] = useState('');
  const [isAvailable, setIsAvailable] = useState(true);
  const [loading, setLoading] = useState(false);

  // Generate next 30 days
  const getNext30Days = () => {
    const days = [];
    for (let i = 1; i <= 30; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      days.push({
        value: date.toISOString().split('T')[0],
        label: date.toLocaleDateString('en-IN', { 
          weekday: 'short', 
          month: 'short', 
          day: 'numeric' 
        })
      });
    }
    return days;
  };

  const addTimeSlot = () => {
    if (newTimeSlot && !timeSlots.includes(newTimeSlot)) {
      setTimeSlots([...timeSlots, newTimeSlot].sort());
      setNewTimeSlot('');
    }
  };

  const removeTimeSlot = (slot: string) => {
    setTimeSlots(timeSlots.filter(s => s !== slot));
  };

  const saveSchedule = async () => {
    if (!selectedDate) {
      alert('Please select a date');
      return;
    }

    setLoading(true);
    try {
      const { projectId } = await import('../../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f2ba4e71/doctor/availability`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify({
          date: selectedDate,
          timeSlots: timeSlots,
          available: isAvailable
        }),
      });

      const result = await response.json();
      if (result.success) {
        alert('Schedule updated successfully!');
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Failed to save schedule:', error);
      alert('Failed to save schedule. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-red-800">
            <Calendar className="w-5 h-5 mr-2" />
            Manage Your Availability Schedule
          </CardTitle>
          <p className="text-sm text-gray-600">
            Set your available times for telemedicine consultations
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Date Selection */}
          <div>
            <Label htmlFor="date">Select Date</Label>
            <select 
              id="date"
              className="w-full p-2 border rounded-md mt-1"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
            >
              <option value="">Choose a date</option>
              {getNext30Days().map((day) => (
                <option key={day.value} value={day.value}>
                  {day.label}
                </option>
              ))}
            </select>
          </div>

          {/* Availability Toggle */}
          <div className="flex items-center space-x-3">
            <Switch
              checked={isAvailable}
              onCheckedChange={setIsAvailable}
            />
            <Label>Available for consultations on this date</Label>
          </div>

          {/* Time Slots Management */}
          {isAvailable && (
            <div>
              <Label className="text-base">Available Time Slots</Label>
              
              {/* Add New Time Slot */}
              <div className="flex space-x-2 mt-3 mb-4">
                <Input
                  type="time"
                  value={newTimeSlot}
                  onChange={(e) => setNewTimeSlot(e.target.value)}
                  className="w-auto"
                />
                <Button onClick={addTimeSlot} variant="outline" size="sm">
                  <Plus className="w-4 h-4 mr-1" />
                  Add Slot
                </Button>
              </div>

              {/* Current Time Slots */}
              <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                {timeSlots.map((slot) => (
                  <div key={slot} className="flex items-center justify-between p-2 bg-red-50 border border-red-200 rounded-lg">
                    <span className="flex items-center text-red-700">
                      <Clock className="w-4 h-4 mr-1" />
                      {slot}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeTimeSlot(slot)}
                      className="h-6 w-6 p-0 text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>

              {timeSlots.length === 0 && (
                <p className="text-gray-500 text-sm">No time slots added yet. Add some time slots above.</p>
              )}
            </div>
          )}

          {/* Save Button */}
          <Button 
            onClick={saveSchedule}
            disabled={loading || !selectedDate}
            className="w-full bg-red-600 hover:bg-red-700"
          >
            {loading ? 'Saving...' : 'Save Schedule'}
          </Button>
        </CardContent>
      </Card>

      {/* Quick Schedule Templates */}
      <Card className="bg-red-50 border-red-200">
        <CardHeader>
          <CardTitle className="text-red-800">Quick Schedule Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              variant="outline"
              onClick={() => setTimeSlots(['09:00', '10:00', '11:00', '12:00'])}
              className="flex flex-col items-center p-4 h-auto"
            >
              <Badge variant="secondary" className="mb-2">Morning Shift</Badge>
              <span className="text-sm">9 AM - 12 PM</span>
            </Button>
            
            <Button
              variant="outline"
              onClick={() => setTimeSlots(['14:00', '15:00', '16:00', '17:00'])}
              className="flex flex-col items-center p-4 h-auto"
            >
              <Badge variant="secondary" className="mb-2">Afternoon Shift</Badge>
              <span className="text-sm">2 PM - 5 PM</span>
            </Button>
            
            <Button
              variant="outline"
              onClick={() => setTimeSlots(['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'])}
              className="flex flex-col items-center p-4 h-auto"
            >
              <Badge variant="secondary" className="mb-2">Full Day</Badge>
              <span className="text-sm">9 AM - 12 PM & 2 PM - 5 PM</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Schedule Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle className="text-gray-800">Schedule Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-gray-600">
            <li>• Each consultation slot is typically 15-20 minutes</li>
            <li>• Schedule updates are immediately visible to patients</li>
            <li>• You can modify your schedule up to 24 hours in advance</li>
            <li>• Emergency slots can be added for urgent cases</li>
            <li>• Consider breaks between slots for documentation</li>
            <li>• Weekend availability helps serve more rural patients</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}