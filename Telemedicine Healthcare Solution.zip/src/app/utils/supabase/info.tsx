// Supabase configuration removed - app now runs in demo mode only
// All data stored locally in browser localStorage