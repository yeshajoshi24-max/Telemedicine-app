// DEMO MODE ONLY - NO DEPLOYMENT REQUIRED
// This telemedicine platform runs entirely client-side
// All data stored in localStorage, no backend needed