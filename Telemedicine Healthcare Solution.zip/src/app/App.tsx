import React, { useState, useEffect } from 'react';
import { LoginPage } from './components/auth/LoginPage';
import { PatientDashboard } from './components/patient/PatientDashboard';
import { HospitalDashboard } from './components/hospital/HospitalDashboard';
import { ASHADashboard } from './components/asha/ASHADashboard';
import { HealthDeptDashboard } from './components/health-dept/HealthDeptDashboard';
import { PharmacyDashboard } from './components/pharmacy/PharmacyDashboard';

interface User {
  id: string;
  email: string;
  name: string;
  userType: string;
  accessToken: string;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session on app load
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    try {
      // Check localStorage for demo session
      const storedUser = localStorage.getItem('nabha_user');
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        setUser(userData);
      }
    } catch (error) {
      console.error('Session check error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (userType: string, userData: User) => {
    setUser(userData);
  };

  const handleLogout = async () => {
    try {
      // Clear localStorage for demo
      localStorage.removeItem('nabha_user');
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
      setUser(null); // Force logout even if there's an error
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full text-center border border-gray-100">
          <div className="mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </div>
            <h1 className="text-2xl mb-2 text-gray-800">Nabha Healthcare Platform</h1>
            <p className="text-sm text-gray-600 mb-6">Connecting 173 villages with quality healthcare</p>
          </div>
          
          <div className="space-y-4">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-200 border-t-blue-600 mx-auto"></div>
            <div className="space-y-2">
              <div className="text-sm text-gray-700">Initializing secure connection...</div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gradient-to-r from-blue-600 to-green-600 h-2 rounded-full animate-pulse" style={{width: '70%'}}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show login page if user is not authenticated
  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Route to appropriate dashboard based on user type
  switch (user.userType) {
    case 'patient':
      return <PatientDashboard user={user} onLogout={handleLogout} />;
    
    case 'hospital':
      return <HospitalDashboard user={user} onLogout={handleLogout} />;
    
    case 'asha':
      return <ASHADashboard user={user} onLogout={handleLogout} />;
    
    case 'health_dept':
      return <HealthDeptDashboard user={user} onLogout={handleLogout} />;
    
    case 'pharmacy':
      return <PharmacyDashboard user={user} onLogout={handleLogout} />;
    
    default:
      return (
        <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full text-center border border-red-100">
            <div className="mb-6">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <h2 className="text-2xl mb-2 text-red-600">Access Error</h2>
              <p className="text-red-500 mb-4">Your account type "<span className="font-mono bg-red-50 px-2 py-1 rounded">{user.userType}</span>" is not recognized in our system.</p>
            </div>
            
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <h3 className="text-sm text-red-800 mb-2">Available User Types:</h3>
              <ul className="text-xs text-red-700 space-y-1">
                <li>• <strong>patient</strong> - Rural patients</li>
                <li>• <strong>hospital</strong> - Civil Hospital staff</li>
                <li>• <strong>asha</strong> - ASHA workers</li>
                <li>• <strong>health_dept</strong> - Punjab Health Department</li>
                <li>• <strong>pharmacy</strong> - Local pharmacies</li>
              </ul>
            </div>
            
            <button 
              onClick={handleLogout}
              className="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors duration-200"
            >
              Logout and Try Again
            </button>
            
            <p className="text-xs text-gray-500 mt-4">
              If this problem persists, please contact your system administrator
            </p>
          </div>
        </div>
      );
  }
}